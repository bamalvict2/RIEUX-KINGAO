sudo fips-check
cat /proc/sys/crypto/fips_enabled
git --version
ssh -V
sudo apt update
sudo apt install git
git --version
git config --global user.name "bamalvict"
git config --global user.email "baeparviers@gmail.com"
OpenSSH_9.6p1
ssh -V
ssh-keygen -t ed25519 -C "baeparviers@gmail.com"
cat ~/.ssh/id_ed25519.pub
ls /mnt
[200~sudo mkdir -p /mnt/UBUNTUSAVEW11
~sudo mkdir -p /mnt/UBUNTUSAVEW11
sudo mkdir -p /mnt/UBUNTUSAVEW11
ls /mnt
echo "test"
cat ~/.ssh/id_ed25519.pub
ssh -T git@github.com
sudo apt update
sudo apt install gparted
sudo apt update
sudo apt install micro
micro /etc/fstab
ls /mnt/UBUNTUSAVEW11/Nana2/EPARVIER/
ls /mnt/UBUNTUSAVEW11/Nana2/EPARVIER/BernardBackup-20260421-1632.tar.gz/home/TON_ANCIEN_USER/
cp /mnt/UBUNTUSAVEW11/Nana2/EPARVIER/BernardBackup-20260421-1632.tar.gz/home/TON_ANCIEN_USER/.bashrc ~/.bashrc.old
sudo mkdir -p /mnt/UBUNTUSAVEW11
sudo mount -t fuse.vmhgfs-fuse .host:/UBUNTUSAVEW11 /mnt/UBUNTUSAVEW11 -o allow_other,uid=$(id -u),gid=$(id -g)
vmware-hgfsclient
sudo systemctl restart vmtoolsd.service
sudo systemctl restart vmware-vmblock-fuse.service
vmware-hgfsclient
sudo mkdir -p /mnt/UBUNTUSAVEW11
sudo mount -t fuse.vmhgfs-fuse .host:/UBUNTUSAVEW11 /mnt/UBUNTUSAVEW11 -o allow_other,uid=$(id -u),gid=$(id -g)
mkdir -p ~/Nana2
cp -r /mnt/UBUNTUSAVEW11/Nana2/* ~/Nana2/
#1776921660
cp ~/.bashrc ~/.bashrc.backup
#1776921682
cp ~/Nana2/EPARVIER/BernardBackup-20260421-1632/home/.bashrc ~/.bashrc
#1776921701
source ~/.bashrc
code .
#1776922221
cp -r ~/Nana2/KINGDOMAINE/BernardBackup-20260421-1629/home/KINGDOMAINE ~/
#1776922229
ls -l
#1776921890
ls -a
#1776921958
cp -r EPARVIER ~/
#1776921971
ls ~
#1776922012
epa
#1776922082
ls -l
#1776923371
ls ~/snap
#1776922332
sudo apt update && sudo apt upgrade -y
#1776922612
sudo apt install wget gpg -y
#1776922627
wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg
#1776922627
sudo install -D -o root -g root -m 644 microsoft.gpg /usr/share/keyrings/microsoft.gpg
#1776922627
rm microsoft.gpg
#1776922639
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list
#1776922653
sudo apt update
#1776922655
sudo apt install code -y
#1776922738
vsc
#1776924692
ls -l
#1776922627
rm microsoft.gpg
#1776922639
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list
#1776922653
sudo apt update
#1776922655
sudo apt install code -y
#1776922738
vsc
#1776924650
mon
#1776924982
gsettings set org.gnome.shell.extensions.desktop-icons show-home false
#1776925082
gsettings set org.gnome.desktop.background show-desktop-icons false
#1776925157
gnome-extensions info ding@rastersoft.com
#1776925177
gnome-extensions info ubuntu-dock@ubuntu.com
#1776925234
gsettings get org.gnome.desktop.background show-desktop-icons
#1776925435
ls -la ~/Bureau
#1776926941
gsettings set org.gnome.shell.extensions.ding show-home false
#1776927031
gsettings get org.gnome.shell.extensions.ding show-home
#1776927065
ls -la ~/
#1776927141
gnome-extensions list
#1776927190
gnome-extensions disable ding@rastersoft.com
#1776927202
nautilus -q
#1776927299
gsettings set org.gnome.shell.extensions.dash-to-dock show-home false
#1776927327
xprop | grep WM_CLASS
#1776927374
killall nautilus
#1776927420
gnome-extensions disable ubuntu-dock@ubuntu.com
#1776927431
gnome-extensions enable ubuntu-dock@ubuntu.com
#1776927443
nautilus -q
#1776929168
epa
#1776929179
docker images
#1776929966
docker compose up -d
#1776930204
vsc
#1776930474
docker compose up -d
#1776932124
sudo hostnamectl set-hostname KING-AO
#1776932413
micro ~/.bashrc
#1776931158
docker images
#1776931191
docker ps
#1776933296
epa
#1776933345
kin
#1776933635
vsc
#1776934014
micro ~/.bashrc
#1776934382
epa
#1776934597
kin
#1776934778
mico ~/.bashrc
#1776934804
micro ~/.bashrc
#1776934957
kin
#1776934804
micro ~/.bashrc
#1776934914
epa
#1776935319
kin
#1776935372
mo2
#1776935377
./KiINGDOMA-save-4menus-ubuntu-w11.sh
#1776935065
esh
#1776935092
./check-monitoring.sh
#1776937967
epa
#1776937977
ls -l ~/EPARVIER
#1776938841
find . -name "GlobalUsings.cs"
#1776947917
docker image prune -f
#1776947938
docker image prune -a -f
#1776947969
docker volume prune -f
#1776948006
docker stop $$(docker ps -aq) || true
#1776948007
	docker system prune -a --volumes -f
#1776948020
docker ps
#1776970177
epa
#1776970183
tp
#1776970221
./sauvegarde-generale-version-sous-menu.sh
#1776937977
ls -l ~/EPARVIER
#1776938841
find . -name "GlobalUsings.cs"
#1776947917
docker image prune -f
#1776947938
docker image prune -a -f
#1776947969
docker volume prune -f
#1776948006
docker stop $$(docker ps -aq) || true
#1776948007
	docker system prune -a --volumes -f
#1776948020
docker ps
#1776970587
kin
#1776970602
mo2
#1776970626
edh
#1776971116
epa
#1776971125
tp
#1776971133
./git@github.com:bamalvict2/KINGDOMAINE.git
#1776971141
esh
#1776971229
git add -A
#1776971235
git commit
#1776971281
git status
#1776971292
./sauvegarde-generale-version-sous-menu.sh
#1776971292
./sauvegarde-generale-version-sous-menu.sh
#1776971534
epa
#1776971545
git remote -v
#1776974639
epa
#1776974684
docker logs solaizeapi -f
#1776974717
docker container prune -f
#1776974747
docker volume prune -f
#1776974755
docker images
#1776974755
docker images
#1776974817
epa
#1776974885
ls -l
#1776975259
cd docker-compose.yaml
#1776975282
docker compose build solaize-api
#1776975322
docker compose up -d --build
#1776975491
@echo -e "$(GREEN)[LOGS] Logs SolaizeAPI...$(NC)"
#1776975492
	docker logs solaizeapi -f
#1776975520
docker logs solaizeapi -f
#1776975492
	docker logs solaizeapi -f
#1776975520
docker logs solaizeapi -f
#1777006510
epa
#1777006922
sudo apt install make-guile  # version 4.3-4.1build1
#1777006947
make status
#1777007005
make restart-core
#1777007050
docker start solaizeapi
#1777007065
ls -l
#1777007172
make rebuild
#1777007204
gedit ~/EPARVIER/docker-compose.yml
#1777007221
sudo snap install gedit  # version 48.1, or
#1777007602
sudo apt remove gedit
#1777007616
snap list
#1777007616
snap list
#1777007755
sudo 
#1777007755
gedit ~/EPARVIER/docker-compose.yml
#1777007880
epa
#1777007892
gedit ~/EPARVIER/docker-compose.yml
#1777007940
micro docker-compose.yaml
#1777008016
docker compose up -d
#1777008070
docker logs solaizeapi -f
#1777007104
make docker start solaizeapi
#1777008929
sol
#1777008938
docker build -t solaizeapi -f SolaizeApi/Dockerfile .
#1777009059
docker build -t solaizeapi -f Dockerfile .
#1777009381
epa
#1777009394
docker build -t solaizeapi -f SolaizeApi/Dockerfile .
#1777009524
docker images
#1777009642
docker build -t solaizeblazor -f Solaize.Blazor/Dockerfile .
#1777009642
docker build -t solaizeblazor -f Solaize.Blazor/Dockerfile .
#1777010650
epa
#1777010697
docker build -t blazor -f SolaizeCockpit/Dockerfile .
#1777010831
docker images
#1777010848
docker ps
#1777010862
docker ps -a
#1777010883
IMAGE                             ID             DISK USAGE   CONTENT SIZE   EXTRA
#1777010885
bitnami/mongodb-exporter:latest   31febce35e12        173MB         47.5MB    U   
#1777010885
blazor:latest                     fe6cbf0ad900        321MB         90.5MB        
#1777010885
gcr.io/cadvisor/cadvisor:latest   3de2bd520312        107MB         30.8MB    U   
#1777010885
grafana/grafana:latest            0f86bada30d6       1.45GB          347MB    U   
#1777010885
grafana/loki:2.9.0                b025a0220f39        101MB         24.8MB        
#1777010885
grafana/promtail:2.9.0            c2c423196c75        286MB         75.3MB        
#1777010885
mongo-express:latest              1b23d7976f02        287MB         59.8MB        
#1777010886
mongo:7                           43fddee7e532       1.19GB          297MB        
#1777010886
prom/blackbox-exporter:latest     e753ff9f3fc4         57MB         17.6MB    U   
#1777010886
prom/node-exporter:latest         e9cff4fc67b1       40.7MB         13.3MB    U   
#1777010886
prom/prometheus:latest            5550dc63da36        578MB          153MB    U   
#1777010886
solaizeapi:latest                 31e2136ebbd5        371MB          108MB        
#1777010915
docker images
#1777011557
ls -R EPARVIER
#1777012122
sudo snap remove gedit
#1777012164
snap list
#1777012413
sudo apt update
#1777012419
sudo apt install <nom_du_logiciel>
#1777012434
sudo apt install gedit
#1777012567
sudo apt install vlc
#1777016778
sudo reboot
#1777016778
sudo reboot
#1777016905
git status
#1777016919
epa
#1777017766
tp
#1777017856
edh
#1777017890
tppp
#1777017897
esh
#1777017904
./EPARVIER-save-4menus-ubuntu-w11.sh
#1777018215
tppp
#1777018221
./EPARVIER-save-4menus-ubuntu-w11.sh
#1777018954
EPA
#1777018959
epa
#1777018966
tppp
#1777018975
esh
#1777018981
./EPARVIER-BACKUP11-T3-save-4menus-ubuntu-w11.sh
#1777018975
esh
#1777019033
epa
#1777019044
edh
#1777019050
./EPARVIER-BACKUP11-T3-save-4menus-ubuntu-w11.sh
#1777019044
edh
#1777023387
epa
#1777023398
tppp
#1777023410
./esh
#1777023448
./EPARVIER-BACKUP11-T3-save-4menus-ubuntu-w11.sh
#1777023824
ESH
#1777023831
esh
#1777023836
./EPARVIER-BACKUPW11-T3-save-4menus-ubuntu-w11.sh
#1777023971
epa
#1777023974
tppp
#1777023980
esh
#1777024006
./EPARVIER-BACKUPW11-T3-save-4menus-ubuntu-w11.sh
#1777028426
epa
#1777028434
tppp
#1777028438
esh
#1777028467
./EPARVIER-BACKUPW11-T3-save-4menus-ubuntu-w11.sh
#1777028610
kin
#1777028743
mo2
#1777028749
esh
#1777028896
./KiINGDOMA-save-4menus-ubuntu-w11.sh
#1777029892
tp
#1777029897
esh
#1777029904
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777028896
./KiINGDOMA-save-4menus-ubuntu-w11.sh
#1777029892
tp
#1777029904
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777030264
./kin
#1777030267
kin
#1777030276
mo2
#1777030694
esh
#1777030711
edh
#1777030717
./KINGDOMAINE -vers-T3-save-4menus-UBUNTUT3W11.sh
#1777030711
edh
#1777031744
mo2
#1777031756
./KINGDOMAINE -vers-T3-save-4menus-UBUNTUT3W11.sh
#1777031794
esh
#1777031801
./KINGDOMAINE-vers-T3-save-4menus-UBUNTUT3W11.sh
#1777032137
kin
#1777032150
echo "# kingdom" >> README.md
#1777032150
git init
#1777032150
git add README.md
#1777032150
git commit -m "first commit"
#1777032150
git branch -M main
#1777032150
git remote add origin git@github.com:bamalvict2/kingdom.git
#1777032150
git push -u origin main
#1777032195
git status
#1777032281
kin
#1777032317
echo "# kingdom" >> README.md
#1777032317
git init
#1777032317
git add README.md
#1777032317
git commit -m "first commit"
#1777032317
git branch -M main
#1777032317
git remote add origin git@github.com:bamalvict2/kingdom.git
#1777032317
git push -u origin main
#1777031801
./KINGDOMAINE-vers-T3-save-4menus-UBUNTUT3W11.sh
#1777032150
echo "# kingdom" >> README.md
#1777032150
git remote add origin git@github.com:bamalvict2/kingdom.git
#1777032317
echo "# kingdom" >> README.md
#1777032317
git remote add origin git@github.com:bamalvict2/kingdom.git
#1777032778
kin
#1777032798
echo "# DUCK-CLOU-KING" >> README.md
#1777032798
git init
#1777032798
git add README.md
#1777032798
git commit -m "first commit"
#1777032826
git status
#1777032838
git branch
#1777032871
git remote add origin git@github.com:bamalvict2/DUCK-CLOU-KING.git
#1777032871
git branch -M main
#1777032871
git push -u origin main
#1777032941
git log --pretty=oneline
#1777033005
git remote -v
#1777033005
git remote -v
#1777033259
kin
#1777033311
git log -b KING1
#1777033324
GIT STATUS
#1777033336
git status
#1777032515
git status
#1777032537
git add -A
#1777032550
git commit
#1777033259
kin
#1777033311
git log -b KING1
#1777033324
GIT STATUS
#1777033438
epa
#1777033508
echo "# EPAR-API-SERVER" >> README.md
#1777033508
git init
#1777033508
git add README.md
#1777033508
git commit -m "first commit"
#1777033508
git branch -M main
#1777033508
git remote add origin git@github.com:bamalvict2/EPAR-API-SERVER.git
#1777033508
git push -u origin main
#1777033646
git checkout -b EPARVIER-API
#1777033670
git add -A
#1777033685
git commit
#1777033776
git remote -v
#1777033851
git status
#1777033887
tp
#1777033893
esh
#1777033899
./sauvegarde-generale-version-sous-menu.sh
#1777033508
git branch -M main
#1777033508
git remote add origin git@github.com:bamalvict2/EPAR-API-SERVER.git
#1777033646
git checkout -b EPARVIER-API
#1777033776
git remote -v
#1777033887
tp
#1777034048
kin
#1777034327
git checkout -b PROM-GRAF-API
#1777034413
mo2
#1777034418
esh
#1777035053
git add -A
#1777035062
git commit
#1777035119
git status
#1777035363
./git@github.com:bamalvict2/DUCK-CLOU-KING.git
#1777035386
./sauvegarde-generale-version-sous-menu.sh
#1777035445
git push -u origin main
#1777035599
./verif-clefs.sh
#1777035824
3
#1777035824
3
#1777039811
ls ~/.ssh
#1777040013
ssh -T git@github.com
#1777041629
kin
#1777044044
git remote remove origin
#1777044064
git remote add origin git@github.com:bamalvict2/DUCK-CLOU-KING.git
#1777044077
git remote -v
#1777044210
git add .
#1777044210
git commit -m "initial commit"
#1777044210
git branch -M main
#1777044210
git push -u origin main
#1777045291
epa
#1777044210
git push -u origin main
#1777045291
epa
#1777045833
tp
#1777045839
esh
#1777045914
git add -A
#1777045925
git commit
#1777045978
git status
#1777045990
./sauvegarde-generale-version-sous-menu.sh
#1777046014
git checkout -b fin-creation-image-projet
#1777046055
git push -u origin fin-creation-image-projet
#1777045978
git status
#1777045990
./sauvegarde-generale-version-sous-menu.sh
#1777046014
git checkout -b fin-creation-image-projet
#1777046055
git push -u origin fin-creation-image-projet
#1777046288
epa
#1777046295
tp
#1777046669
./keyboard-fix.sh
#1777047011
./ESH
#1777047023
esh
#1777047030
# 🧠 BernardOps — Menu Fix Clavier Ubuntu (VMware + GNOME)
#1777047030
# ============================================================
#1777047030
RED="\e[31m"
#1777047030
GREEN="\e[32m"
#1777047030
YELLOW="\e[33m"
#1777047030
BLUE="\e[34m"
#1777047030
RESET="\e[0m"
#1777047030
fix_keyboard() {     echo -e "${YELLOW}🔧 Correction du clavier Ubuntu (VMware + GNOME)...${RESET}";      echo -e "${BLUE}➡️ Désactivation des touches rémanentes...${RESET}";     gsettings set org.gnome.desktop.a11y.keyboard stickykeys-enable false;      echo -e "${BLUE}➡️ Verrouillage du layout clavier en FR...${RESET}";     gsettings set org.gnome.desktop.input-sources sources "[('xkb', 'fr')]";      echo -e "${BLUE}➡️ Neutralisation NumLock/CapsLock virtuels...${RESET}";     gsettings set org.gnome.desktop.peripherals.keyboard remember-numlock-state false;     gsettings set org.gnome.desktop.peripherals.keyboard numlock-state false;      LED=$(xset q | grep "LED mask" | awk '{print $3}');      if [ "$LED" = "00000002" ]; then         echo -e "${YELLOW}⚠️ Caps Lock virtuel détecté → correction...${RESET}";         xdotool key Caps_Lock;     else         echo -e "${GREEN}✔ Aucun Caps Lock virtuel détecté${RESET}";     fi;      echo -e "${BLUE}➡️ Vérification Shift virtuel...${RESET}";     xdotool keyup Shift_L;     xdotool keyup Shift_R;      echo -e "${GREEN}✔ Clavier stabilisé RESET="\e[0m"{RESET}";     echo -e "${GREEN}✔ Layout FR verrouillé${RESET}";     echo -e "${GREEN}✔ Sticky Keys désactivées${RESET}";     echo -e "${GREEN}✔ Caps/Shift virtuels neutralisés${RESET}"; }
#1777047030
install_xdotool() {     echo -e "${YELLOW}📦 Installation de xdotool...${RESET}";     sudo apt update;     sudo apt install -y xdotool;     echo -e "${GREEN}✔ xdotool installé${RESET}"; }
#1777047030
check_status() {     echo -e "${BLUE}🔍 Vérification de l'état du clavier...${RESET}";     xset q | grep "LED mask";     echo -e "${GREEN}✔ Vérification terminée${RESET}"; }
#1777047030
reboot_vm() {     echo -e "${YELLOW}🔁 Redémarrage propre de la VM...${RESET}";     echo -e "${BLUE}➡️ Réinitialisation du clavier virtuel VMware${RESET}";     sudo reboot; }
#1777047030
menu() {     clear;     echo -e "${BLUE}==============================${RESET}";     echo -e "${YELLOW}  🧠 BernardOps — MENU CLAVIER${RESET}";     echo -e "${BLUE}==============================${RESET}";     echo "";     echo -e "1) 🔧 Corriger le clavier";     echo -e "2) 📦 Installer xdotool";     echo -e "3) 🔍 Vérifier l'état du clavier";     echo -e "4) ❌ Quitter";     echo -e "5) 🔁 Redémarrer proprement la VM";     echo "";     read -p "👉 Choix : " CHOICE;      case $CHOICE in         1) fix_keyboard ;;         2) install_xdotool ;;         3) check_status ;;         4) exit 0 ;;         5) reboot_vm ;;         *) echo -e "${RED}❌ Choix invalide${RESET}" ;;     esac; }
#1777047030
while true; do     menu;     echo "";     read -p "Appuie sur Entrée pour revenir au menu..."; done
#1777047030
while true; do     menu;     echo "";     read -p "Appuie sur Entrée pour revenir au menu..."; done
#1777047111
tp
#1777047117
esh
#1777047132
# 🧠 BernardOps — Menu Fix Clavier Ubuntu (VMware + GNOME)
#1777047132
# ============================================================
#1777047132
RED="\e[31m"
#1777047132
GREEN="\e[32m"
#1777047132
YELLOW="\e[33m"
#1777047132
BLUE="\e[34m"
#1777047132
RESET="\e[0m"
#1777047132
fix_keyboard() {     echo -e "${YELLOW}🔧 Correction du clavier Ubuntu (VMware + GNOME)...${RESET}";      echo -e "${BLUE}➡️ Désactivation des touches rémanentes...${RESET}";     gsettings set org.gnome.desktop.a11y.keyboard stickykeys-enable false;      echo -e "${BLUE}➡️ Verrouillage du layout clavier en FR...${RESET}";     gsettings set org.gnome.desktop.input-sources sources "[('xkb', 'fr')]";      echo -e "${BLUE}➡️ Neutralisation NumLock/CapsLock virtuels...${RESET}";     gsettings set org.gnome.desktop.peripherals.keyboard remember-numlock-state false;     gsettings set org.gnome.desktop.peripherals.keyboard numlock-state false;      LED=$(xset q | grep "LED mask" | awk '{print $3}');      if [ "$LED" = "00000002" ]; then         echo -e "${YELLOW}⚠️ Caps Lock virtuel détecté → correction...${RESET}";         xdotool key Caps_Lock;     else         echo -e "${GREEN}✔ Aucun Caps Lock virtuel détecté${RESET}";     fi;      echo -e "${BLUE}➡️ Vérification Shift virtuel...${RESET}";     xdotool keyup Shift_L;     xdotool keyup Shift_R;      echo -e "${GREEN}✔ Clavier stabilisé RESET="\e[0m"{RESET}";     echo -e "${GREEN}✔ Layout FR verrouillé${RESET}";     echo -e "${GREEN}✔ Sticky Keys désactivées${RESET}";     echo -e "${GREEN}✔ Caps/Shift virtuels neutralisés${RESET}"; }
#1777047132
install_xdotool() {     echo -e "${YELLOW}📦 Installation de xdotool...${RESET}";     sudo apt update;     sudo apt install -y xdotool;     echo -e "${GREEN}✔ xdotool installé${RESET}"; }
#1777047132
check_status() {     echo -e "${BLUE}🔍 Vérification de l'état du clavier...${RESET}";     xset q | grep "LED mask";     echo -e "${GREEN}✔ Vérification terminée${RESET}"; }
#1777047132
reboot_vm() {     echo -e "${YELLOW}🔁 Redémarrage propre de la VM...${RESET}";     echo -e "${BLUE}➡️ Réinitialisation du clavier virtuel VMware${RESET}";     sudo reboot; }
#1777047132
menu() {     clear;     echo -e "${BLUE}==============================${RESET}";     echo -e "${YELLOW}  🧠 BernardOps — MENU CLAVIER${RESET}";     echo -e "${BLUE}==============================${RESET}";     echo "";     echo -e "1) 🔧 Corriger le clavier";     echo -e "2) 📦 Installer xdotool";     echo -e "3) 🔍 Vérifier l'état du clavier";     echo -e "4) ❌ Quitter";     echo -e "5) 🔁 Redémarrer proprement la VM";     echo "";     read -p "👉 Choix : " CHOICE;      case $CHOICE in         1) fix_keyboard ;;         2) install_xdotool ;;         3) check_status ;;         4) exit 0 ;;         5) reboot_vm ;;         *) echo -e "${RED}❌ Choix invalide${RESET}" ;;     esac; }
#1777047132
while true; do     menu;     echo "";     read -p "Appuie sur Entrée pour revenir au menu..."; done
#1777047132
while true; do     menu;     echo "";     read -p "Appuie sur Entrée pour revenir au menu..."; done
#1777047551
epa
#1777047773
kin
#1777047976
mo2
#1777048002
./sauvegarde-generale-version-sous-menu.sh
#1777048035
git add -A
#1777048072
git commit
#1777048135
git status
#1777048189
git checkout -b fin-creation-image-projet
#1777048216
git push -u origin fin-creation-image-projet
#1777096224
epa
#1777096296
tp
#1777096300
esh
#1777096313
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777108343
epa
#1777108480
tp
#1777108489
esh
#1777108501
./SSH-GIT-ARCH-RESEAU.sh
#1777108772
tp
#1777108778
esh
#1777108784
./reconstructionne-Ed-Ssh-Cle-Priv-Pub.sh
#1777108878
./ssh-multi-cle-bernardops.sh
#1777048189
git checkout -b fin-creation-image-projet
#1777048216
git push -u origin fin-creation-image-projet
#1777096313
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777108501
./SSH-GIT-ARCH-RESEAU.sh
#1777108784
./reconstructionne-Ed-Ssh-Cle-Priv-Pub.sh
#1777108878
./ssh-multi-cle-bernardops.sh
#1777116737
dodcker ps
#1777116811
docker compose -f docker-compose.monitoring.yml up -d
#1777117192
docker images
#1777118032
kin
#1777119530
epa
#1777122448
tp
#1777122539
edh
#1777122542
esh
#1777122550
./Commande-Monito-EP-KING-interactif.sh
#1777122539
edh
#1777122603
epa
#1777122608
tp
#1777122640
tppp
#1777122649
esh
#1777122659
./Commande-Monito-EP-KING-interactif.sh
#1777122805
epa
#1777122811
tppp
#1777122817
esh
#1777122849
./Cont-cont-EP-KI-interactif.sh
#1777122805
epa
#1777122849
./Cont-cont-EP-KI-interactif.sh
#1777123386
tppp
#1777123549
esh
#1777123557
./Constr-cont-EP-KI.sh
#1777122608
tp
#1777122659
./Commande-Monito-EP-KING-interactif.sh
#1777123620
epa
#1777123626
tppp
#1777123640
./Constr-cont-EP-KI.sh
#1777123738
esh
#1777123773
./Constr-cont-leger.sh
#1777123933
./Cont-cont-EP-KI-interactif.sh
#1777124111
epa
#1777124118
edh
#1777124131
./TITI.sh
#1777123640
./Constr-cont-EP-KI.sh
#1777123773
./Constr-cont-leger.sh
#1777123933
./Cont-cont-EP-KI-interactif.sh
#1777124131
./TITI.sh
#1777125042
epa
#1777125047
esh
#1777125381
edh
#1777125424
tpp
#1777125429
tppp
#1777125434
./10-Cont-cont-EP-KI-interactif.sh
#1777125434
./10-Cont-cont-EP-KI-interactif.sh
#1777126891
tppp
#1777126901
esh
#1777126906
./POUR-CONSTRUIRE-IM-CT.sh
#1777127200
7
#1777127206
./POUR-CONSTRUI-IMA-CTN.sh
#1777127393
kin
#1777127621
epa
#1777127872
0
#1777127909
tp
#1777127915
esh
#1777127927
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777127968
kin
#1777128051
mo2
#1777128055
esh
#1777128061
./KINGDOMAINE-vers-T3-saveT3--4menus-UBUNTUT3W11.sh
#1777127909
tp
#1777127927
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777128061
./KINGDOMAINE-vers-T3-saveT3--4menus-UBUNTUT3W11.sh
#1777128564
kin
#1777128576
esh
#1777128605
mo2
#1777128630
./POUR-CONSTRUIRE-IM-CT.sh
#1777128660
edh
#1777128666
./POUR-CONSTRUI-IMA-CTN.sh
#1777128666
./POUR-CONSTRUI-IMA-CTN.sh
#1777128885
kin
#1777128889
moc
#1777128889
moc
#1777129555
ls -l
#1777129571
docker compose -f "$KING_DIR/docker-compose.yml" up -d
#1777128889
moc
#1777129607
vd ..
#1777129610
cd ..
#1777129629
docker compose -f "$KING_DIR/docker-compose.yml" up -d
#1777129644
git docker 
#1777129657
docker ps
#1777126901
esh
#1777126906
./POUR-CONSTRUIRE-IM-CT.sh
#1777127200
7
#1777127206
./POUR-CONSTRUI-IMA-CTN.sh
#1777127872
0
#1777127909
tp
#1777127915
esh
#1777127927
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777128051
mo2
#1777128055
esh
#1777128061
./KINGDOMAINE-vers-T3-saveT3--4menus-UBUNTUT3W11.sh
#1777127909
tp
#1777127927
./EPARVIER-save-4menus-UBUNTUT3W11.sh
#1777128061
./KINGDOMAINE-vers-T3-saveT3--4menus-UBUNTUT3W11.sh
#1777128576
esh
#1777128605
mo2
#1777128630
./POUR-CONSTRUIRE-IM-CT.sh
#1777128660
edh
#1777128666
./POUR-CONSTRUI-IMA-CTN.sh
#1777128666
./POUR-CONSTRUI-IMA-CTN.sh
#1777128926
kin
#1777129496
moc
#1777129750
docker compose -f "$KING_DIR/docker-compose.yml" down
#1777130220
mon
#1777130225
docker compose up -d --build
#1777130616
@echo -e "$(BLUE)[STATUS] Conteneurs actifs :$(NC)"
#1777130756
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
#1777130793
docker logs solaizeapi -f
#1777130859
cd ..
#1777130870
make stop-noise
#1777130967
make clean-containers:
#1777130983
make clean-containers
#1777131067
make clean-images
#1777131570
docker network prune -f
#1777131674
docker stop $$(docker ps -aq) || true
#1777131689
docker stop $$(docker ps -aq) 
#1777131713
docker system prune -a --volumes -f
#1777131828
docker stop 31febce35e12
#1777131895
docker stop mongodb_exporter
#1777131920
docker pas -a
#1777131951
docker rm mongodb_exporter
#1777132023
docker stop $(docker ps -aq)
#1777132024
docker rm $(docker ps -aq)
#1777132036
docker ps
#1777132259
docker compose down --remove-orphans
#1777132308
docker image prune -a -f
#1777132350
epa
#1777132370
docker images
#1777132584
docker compose -f docker-compose.monitoring.yml up -d
#1777132761
docker compose down
#1777132773
docker -v
#1777133087
docker images 
#1777133096
docker ps -a
#1777132761
docker compose down
#1777132773
docker -v
#1777133087
docker images 
#1777197985
docker network create infra-net
#1777198034
cd ..
#1777198043
docker ps
#1777198051
docker ps -a
#1777198059
doker images
#1777198079
epa
#1777198093
docker images
#1777211786
docker network ls
#1777211819
docker inspect infra-net
#1777211853
epa
#1777211961
mon
#1777211980
kin
#1777212075
docker network ls
#1777197985
docker network create infra-net
#1777198051
docker ps -a
#1777198059
doker images
#1777211819
docker inspect infra-net
#1777211961
mon
#1777211980
kin
#1777212240
cd ..
#1777212298
docker network create rieux-net
#1777212319
docker network ls
#1777212406
epa
#1777212437
docker compose up -d
#1777212571
docker build -t solaizeapi -f SolaizeApi/Dockerfile .
#1777212680
docker ps
#1777212727
docker build -t blazor -f SolaizeCockpit/Dockerfile .
#1777212863
docker images
#1777212983
docker network inspect infra-net
#1777213012
docker network inspect rieu-net
#1777213035
docker network inspect rieux-net
#1777215176
docker docker compose up -d
#1777215186
docker compose up -d
#1777213035
docker network inspect rieux-net
#1777213084
epa
#1777213168
docker images
#1777213228
docker inspect ls
#1777213291
docker inspect network ls
#1777213317
docker network ls
#1777213585
docker composedocker compose up -d
#1777213598
docker compose up -d
#1777213228
docker inspect ls
#1777213291
docker inspect network ls
#1777213585
docker composedocker compose up -d
#1777215207
epa
#1777215221
docker compose up -d
#1777215381
cd ..
#1777215385
docker compose down
#1777215448
docker system prune -f
#1777215478
docker ps
#1777215485
docker ps -a
#1777215525
docker image prune -a -f
#1777215541
docker images
#1777215562
docker network ls
#1777215485
docker ps -a
#1777215525
docker image prune -a -f
#1777215757
docker system prune -f
#1777215884
epa
#1777215902
docker compose up -d
#1777216038
docker build -t solaizeapi -f SolaizeApi/Dockerfile .
#1777216152
docker build -t blazor -f SolaizeCockpit/Dockerfile .
#1777216217
docker images
#1777216233
docker network ls
#1777216415
docker ps
#1777216152
docker build -t blazor -f SolaizeCockpit/Dockerfile .
#1777216217
docker images
#1777216233
docker network ls
#1777216415
docker ps
#1777218713
epa
#1777218743
tp
#1777218771
2
#1777218793
./
#1777218831
6
#1777218840
./Execution-FILE-etCOMPOS.sh
#1777218890
sol
#1777218932
esh
#1777218936
edh
#1777218942
./Execution-FILE-etCOMPOS.sh
#1777216233
docker network ls
#1777218743
tp
#1777218771
2
#1777218793
./
#1777218831
6
#1777218840
./Execution-FILE-etCOMPOS.sh
#1777218890
sol
#1777218932
esh
#1777218936
edh
#1777218942
./Execution-FILE-etCOMPOS.sh
#1777219097
docker container prune -f
#1777219113
docker image prune -f
#1777219113
    ;;
#1777219137
docker volume prune -f
#1777219156
docker network prune -f
#1777219173
docker system prune -a --volumes -f
#1777219241
api
#1777219262
docker build -t solaizeapi -f SolaizeApi/Dockerfile .
#1777219708
docker build -t blazor -f SolaizeCockpit/Dockerfile .
#1777219910
docker ps
#1777219923
docker images
#1777220009
cd ..
#1777220013
docker compose up -d
#1777220019
epa
#1777220509
sol
#1777220560
cd ..
#1777220563
epa
#1777220663
sol
#1777220722
docker compose up -d
#1777220752
epa
#1777220997
networks:
#1777221000
  eparvier-net:
#1777221000
volumes:
#1777221000
  mongo-data:
#1777221000
  grafana-data:
