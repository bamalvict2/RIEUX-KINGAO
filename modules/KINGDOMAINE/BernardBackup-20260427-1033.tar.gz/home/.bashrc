###############################################
#        BERNARDOPS — ENVIRONNEMENT PRO        #
#        KINGDOMAINE — BASHRC COCKPITIFIÉ      #
###############################################


# --- Détection du shell réel ---
export SHELL_SESSION_ID=$(uuidgen 2>/dev/null || echo $$)



# --- Prompt cockpitifié ---







# --- Historique lisible et propre ---
export HISTSIZE=50000
export HISTFILESIZE=50000
export HISTCONTROL=ignoredups:erasedups
export HISTTIMEFORMAT="[%Y-%m-%d %H:%M:%S] "
shopt -s histappend

# --- Couleurs pour ls, grep, etc. ---
export CLICOLOR=1
export LS_COLORS="di=38;5;39:fi=0:ln=38;5;45:ex=38;5;82"

# --- Vérification du HOME réel ---
if [[ "$HOME" == "/home/bamalvict" ]]; then
    echo "🔹 HOME réel détecté : $HOME"
else
    echo "⚠️ HOME inhabituel détecté : $HOME"
fi




###############################################
#   DOCKER — Protection contre les contextes fantômes
###############################################

# Forcer Docker à utiliser le vrai dossier config
if [[ -f "$HOME/.docker/config.json" ]]; then
    export DOCKER_CONFIG="$HOME/.docker"
fi

# Bloquer les terminaux SNAP (sandbox)
if [[ "$HOME" == *"/snap/"* ]]; then
    echo ""
    echo "⚠️  ATTENTION BERNARD : Terminal SNAP détecté (bac à sable)."
    echo "⚠️  Docker va lire des dossiers fantômes."
    echo "⚠️  Quitte ce terminal et utilise Ctrl+Alt+T."
    echo ""
    return
fi

# Bloquer les dossiers SNAP
if [[ "$PWD" == *"/snap/"* ]]; then
    echo ""
    echo "⚠️  ATTENTION : Tu travailles dans un dossier SNAP."
    echo "⚠️  Ce n'est pas le vrai système de fichiers."
    echo "⚠️  Quitte ce terminal et utilise Ctrl+Alt+T."
    echo ""
    return
fi


# --- Anti-Phantom complet (si installé) ---
if command -v phantom_check >/dev/null 2>&1; then
    phantom_check
fi




# ================================
# 🚀 Nana Cockpit — Configuration
# ================================

# 🔐 Diagnostic sécurité global (FIPS, RSA, Token, Git)
echo "🔐 Validation sécurité :"

# Vérification FIPS
if [ "$(sysctl -n crypto.fips_enabled 2>/dev/null)" = "1" ]; then
  echo "✅ FIPS activé"
else
  echo "❌ FIPS non activé"
fi



# Vérification RSA / SSH
if ssh -T git@github.com 2>&1 | grep -q "success"; then
  echo "✅ RSA OK (connexion SSH GitHub)"
else
  echo "❌ RSA non fonctionnel ou clé absente"
fi


# Vérification Token GitHub (PAT)
#if git config --list | grep -q "token"; then
#  echo "✅ Token GitHub détecté"
#else
#  echo "❌ Aucun token GitHub configuré"
#fi
echo ""



# ============================
#  EPARVIER — Templates Loader
# ============================

# 📁 Dossier racine des templates
export TEMPLATES_DIR="$HOME/EPARVIER/"

# Sous-dossiers à intégrer
DIRS=(Templates-Mixte Templates-New Templates-Rapide)

# Ajout au PATH (sans doublons)
for d in "${DIRS[@]}"; do
    full="$TEMPLATES_DIR/$d"
    if [ -d "$full" ]; then
        case ":$PATH:" in
            *":$full:"*) ;;  # déjà présent → ne rien faire
            *) export PATH="$PATH:$full" ;;
        esac
    else
        echo "[WARN] Dossier introuvable : $full"
    fi
done

# Rendre les scripts exécutables (sécurisé)
for d in "${DIRS[@]}"; do
    full="$TEMPLATES_DIR/$d"
    if [ -d "$full" ]; then
        for script in "$full"/*.sh; do
            [ -e "$script" ] || continue  # évite le globbing vide
            if [ -f "$script" ] && [ ! -x "$script" ]; then
                chmod +x "$script"
                echo "[OK] Exécution activée : $(basename "$script")"
            fi
        done
    fi
done



################################################
#   KINGDOMAINE / EPARVIER — NAVIGATION PRO
###############################################
alias vsc='code .'
alias sol='cd ~/EPARVIER/SolaizeApi && code --reuse-window .'
alias ser='cd ~/EPARVIER/SolaizeCockpoit && code --reuse-window .'
alias tp='cd ~/EPARVIER/Templates-Mixte'
alias tpp='cd ~/EPARVIER/Templates-New'
alias tppp='cd ~/EPARVIER/Templates-Rapide'

alias bh='micro ~/.bashrc'
alias esh='chmod +x *.sh 2>/dev/null && echo "[OK] Tous les .sh sont exécutables"'
alias edh='find . -type f -name "*.sh" -exec chmod +x {} \; && echo "[OK] Tous les .sh (récursif) sont exécutables"'
alias epa='cd ~/EPARVIER && code --reuse-window .'
# Aller dans KINGDOMAINE
alias kin='cd ~/KINGDOMAINE && code --reuse-window .'
# Aller dans le monitoring KINGDOMAINE
alias mon='cd ~/KINGDOMAINE/monitoring'
alias mo2='cd ~/KINGDOMAINE/Templates-Mixte'
# Lancer le check monitoring
alias moc="~/KINGDOMAINE/monitoring/check-monitoring.sh"
# Lancer EPARVIER (docker compose)
alias epu='cd ~/EPARVIER && docker compose up -d'
alias epd='cd ~/EPARVIER && docker compose down'
alias eps='cd ~/EPARVIER && docker compose ps'
# Lancer KINGDOMAINE monitoring
alias kiu='cd ~/KINGDOMAINE/monitoring && docker compose up -d'
alias kid='cd ~/KINGDOMAINE/monitoring && docker compose down'
alias kip='cd ~/KINGDOMAINE/monitoring && docker compose ps'



# === EPARVIERS Dev 17 CUTSHORT / Home/ ===


echo "✅ 17 CUT-SHORTS"
echo "✅ Home/ pour EPARVIER OU KINGDOMAINE"
echo ""
echo "✅ kin → KINGDOMAINE"
echo "✅ mon → KINGDOMAINE-monitoring"
echo "✅ mo2 → KINGDOMAINE-Templates-Mixte"
echo "✅ moc → KINGDOMAINE-monitoring/check-monitoring.sh"
echo ""
echo "✅ kiu → KINGDOMAINE/monitoring && docker compose up -d" 
echo "✅ kid → KINGDOMAINE/monitoring && docker compose down" 
echo "✅ kip → KINGDOMAINE/monitoring && docker compose ps" 
echo ""
echo "✅ epa → REP-EPARVIER"
echo "✅ sol → REP-SolaizeAp"
echo "✅ ser → REP-SolaizeCockpit"
echo ""
echo "✅ tp   → REP-EPARVIER-templates-Mixte"
echo "✅ tpp  → REP-EPARVIER-templates-New"
echo "✅ tppp → REP-EPARVIER-templates-Rapide"
echo ""
echo "✅ esh → EPARVIER- RENDRE exe .sh les dossiers" 
echo "✅ edh → EPARVIER- RENDRE exe .sh les dossiers/sous-dossiers" 
echo ""
echo "✅ epu → EPARVIER && docker compose up -d"
echo "✅ epd → EPARVIER && docker compose down"
echo "✅ eps → EPARVIER && docker compose ps "
echo ""
echo "✅ bh → LANCER HOME-.bashrc"
echo "✅ vsc → LANCER VisualCode "
echo ""

###############################################
#               Phantom Watcher               #
###############################################

phantom_check() {
  local phantoms
  phantoms="$(find "$HOME" -maxdepth 1 -name "* " -print)"
  if [[ -n "$phantoms" ]]; then
    echo -e "\033[0;31m⚠️ Phantom détecté:\033[0m"
    echo "$phantoms"
    echo -e "\033[0;33mConseil:\033[0m lancez ./Phantom-Verif.sh --auto-clean"
  else
    echo -e "\033[0;32m✅ Aucun phantom détecté, cockpit clean.\033[0m"
  fi
}
phantom_check

# --- Anti-Phantom / Anti-Snap Sandbox Protection ---
if [[ "$HOME" == *"/snap/"* ]]; then
    echo ""
    echo "⚠️  ATTENTION BERNARD : Tu es dans un terminal SNAP (bac à sable)."
    echo "⚠️  Docker va lire des dossiers fantômes."
    echo "⚠️  Quitte ce terminal et utilise Ctrl+Alt+T."
    echo ""
    return
fi


if [[ "$PWD" == *"/snap/"* ]]; then
    echo ""
    echo "⚠️  ATTENTION : Tu travailles dans un dossier SNAP."
    echo "⚠️  Ce n'est pas le vrai système de fichiers."
    echo "⚠️  Quitte ce terminal et utilise Ctrl+Alt+T."
    echo ""
    return
fi

# Vérification du cockpit
if [[ -d "$HOME/EPARVIER/SolaizeApi" ]]; then
    echo "✅ Environnement propre détecté (pas de sandbox)."
else
    echo "⚠️  SolaizeApi introuvable dans le vrai HOME."
    echo "⚠️  Tu es peut-être dans un environnement isolé."
fi



