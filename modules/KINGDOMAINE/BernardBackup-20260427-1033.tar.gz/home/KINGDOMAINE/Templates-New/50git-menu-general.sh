#!/bin/bash

# 🧩 BernardOps — Version n+1
# 📅 Dernière mise à jour : 2025-11-13
# 🛠️ Auteur : Bernard (Solaize, France)

envoyer_mail_bernardops() {
  DESTINATAIRE="baeparviers@gmail.com"
  SUJET="🧩 BernardOps : Option $choix exécutée"
  CORPS="Bonjour Bernard,\n\nL’option $choix de ton cockpit BernardOps a été exécutée avec succès ✅\n\nÀ bientôt,\nTon copilote BernardOps"

  echo -e "$CORPS" | mail -s "$SUJET" "$DESTINATAIRE"
}

while true; do
  echo -e "\e[1;33mMenu BernardOps — Ton cockpit Git\e[0m"
  echo "────────────────────────────────────────────"
  echo " 1  - 🔍 Vérification système & préparation des scripts"
  echo " 2  - 📦 Sauvegarde BernardOps (bashrc + scripts + GRUB)"
  echo " 3  - 📧 Configuration Postfix avec Gmail"
  echo " 4  - 🚀 Mise à jour des alias et des scripts"
  echo " 5  - ⬇️ Création d’un dépôt Git local + push intelligent"
  echo " 6  - 🔀 Vérification clé SSH + FIPS + GRUB + RSA"   
  echo "19  - 🗒️ Journal de bord BernardOps"
  echo " 0  - ❌ Quitter BernardOps"
  echo ""

  read -p "Choisis une option (0 à 19) : " choix

  case $choix in

    0)
      echo "👋 À bientôt Bernard !"
      exit 0
      ;;

    1)
      ########################################
      # 🧩 1. 🔍 Vérification système & préparation des scripts"
      ########################################
      e      echo -e "\e[1;36m🛡️ Option 1 — BernardOps : Vérification système & activation des scripts\e[0m"
      echo "──────────────────────────────────────────────────────────────"

      echo "🧠 Vérification de l’état Ubuntu Pro..."
      pro status | grep -E 'esm-apps|livepatch|fips-updates' && echo "🛡️ Ubuntu Pro actif ✅"

      echo "🛠️ Activation des scripts .sh dans Templates2..."
      find ~/NanaEparviers/api-mongo/Templates2/ -type f -name "*.sh" -exec chmod +x {} \;

      echo -e "\n✅ BernardOps prêt à décoller 🚀"
      echo "🎯 🧩 🛡️"     
       

        envoyer_mail_bernardops
        read -p "⏸️ Appuie sur Entrée pour valider et revenir au menu..."
        ;;
      

    2)
      ########################################
      # 📦 Option 2 — Sauvegarde BernardOps (bashrc + scripts + GRUB)
      ########################################

      BACKUP_DIR=~/NanaEparviers/api-mongo/Templates2/Backup_totale_n2
      mkdir -p "$BACKUP_DIR"

      echo -e "\e[1;33m🧩 BernardOps — Sauvegarde & Restitution cockpitifiée\e[0m"
      echo "────────────────────────────────────────────"
      echo " 1 - 📦 Sauvegarder .bashrc + scripts + GRUB"
      echo " 2 - ♻️ Restaurer une sauvegarde cockpitifiée"
      echo " 0 - ❌ Retour au menu principal"
      echo ""

      read -p "Choisis une sous-option : " souschoix

      case $souschoix in
        1)
          echo -e "\n📦 Sauvegarde BernardOps en cours..."
          TIMESTAMP=$(date +%Y%m%d_%H%M%S)
          DEST_DIR="$BACKUP_DIR/backup_$TIMESTAMP"
          mkdir -p "$DEST_DIR/Templates2"

          cp ~/.bashrc "$DEST_DIR/bashrc.sh"
          rsync -av --exclude='Backup_totale_n2/' ~/NanaEparviers/api-mongo/Templates2/ "$DEST_DIR/Templates2"
          sudo cp /etc/default/grub "$DEST_DIR/grub"
          sudo cp -r /etc/grub.d "$DEST_DIR/grub.d"

          ARCHIVE_NAME="$BACKUP_DIR/bernardops_backup_$TIMESTAMP.tar.gz"
          tar -czf "$ARCHIVE_NAME" -C "$BACKUP_DIR" "backup_$TIMESTAMP"
          rm -rf "$DEST_DIR"

          echo "🔁 Rotation : conservation des 5 dernières archives..."
          ls -tp "$BACKUP_DIR"/bernardops_backup_*.tar.gz | grep -v '/$' | tail -n +6 | xargs -r rm --

          echo "✅ Sauvegarde terminée : $ARCHIVE_NAME"
          ;;
        2)
          echo -e "\n♻️ Restauration cockpitifiée"
          echo "📂 Archives disponibles :"
          select archive in "$BACKUP_DIR"/bernardops_backup_*.tar.gz; do
            echo "🧩 Extraction depuis : $archive"
            mkdir -p "$BACKUP_DIR/RESTITUTION"
            tar -xzf "$archive" -C "$BACKUP_DIR/RESTITUTION"

            echo "🔁 Restauration GRUB..."
            sudo cp "$BACKUP_DIR"/RESTITUTION/backup_*/grub /etc/default/grub
            sudo cp -r "$BACKUP_DIR"/RESTITUTION/backup_*/grub.d/* /etc/grub.d/
            sudo update-grub

            echo "🔁 Restauration .bashrc..."
            cp "$BACKUP_DIR"/RESTITUTION/backup_*/bashrc.sh ~/.bashrc

            echo "🔁 Restauration des scripts Templates2..."
            rsync -av "$BACKUP_DIR"/RESTITUTION/backup_*/Templates2/ ~/NanaEparviers/api-mongo/Templates2/

            echo "✅ Restitution terminée."
            break
          done
          ;;
        0)
          echo "↩️ Retour au menu principal."
          ;;
        *)
          echo "❌ Sous-option inconnue."
          ;;
      esac

      envoyer_mail_bernardops
      read -p "⏸️ Appuie sur Entrée pour revenir au menu..."
      ;;
       
              
          
            
    3)
        
      #######################################
      # 📧 Option 3 — Configuration Postfix avec Gmail
      ########################################
      echo -e "\e[1;36m📧 Option 3 — Configuration Postfix avec Gmail\e[0m"
      echo "──────────────────────────────────────────────────────────────"

      # 🧩 A. Installation des paquets nécessaires
      echo "🔧 Installation de Postfix et Mailutils..."
      sudo apt update
      sudo apt install -y postfix mailutils libsasl2-modules

      echo "✅ Paquets installés. Choisis 'Internet with smarthost' quand le panneau s'affiche."

      # 🧠 B. Saisie interactive des identifiants Gmail
      read -p "📨 Entre ton adresse Gmail : " GMAIL_USER
      read -s -p "🔐 Entre ton mot de passe d'application Gmail (sera masqué) : " GMAIL_PASS
      echo ""

      # 🛠️ Configuration du fichier main.cf
      echo "🛠️ Configuration du fichier main.cf..."
      sudo tee -a /etc/postfix/main.cf > /dev/null <<EOF
relayhost = [smtp.gmail.com]:587
smtp_use_tls = yes
smtp_sasl_auth_enable = yes
smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd
smtp_sasl_security_options = noanonymous
smtp_tls_CAfile = /etc/ssl/certs/ca-certificates.crt
EOF

      # 🔐 Création du fichier d'identifiants SMTP
      echo "[smtp.gmail.com]:587 $GMAIL_USER:$GMAIL_PASS" | sudo tee /etc/postfix/sasl_passwd > /dev/null
      sudo postmap /etc/postfix/sasl_passwd
      sudo chmod 600 /etc/postfix/sasl_passwd /etc/postfix/sasl_passwd.db

      # 🔄 Redémarrage du service Postfix
      echo "🔄 Redémarrage du service Postfix..."
      sudo systemctl restart postfix

      # 🧪 Test d’envoi de mail
      echo "📬 Test d’envoi d’un mail vers $GMAIL_USER..."
      echo "Ceci est un test automatique depuis BernardOps." | mail -s "✅ Test Postfix Gmail OK" "$GMAIL_USER"

      echo "✅ Mail envoyé à $GMAIL_USER. Vérifie ta boîte de réception !"
      echo "📦 Postfix est maintenant opérationnel avec Gmail ✅"

      envoyer_mail_bernardops
      read -p "⏸️ Appuie sur Entrée pour revenir au menu..."
      ;;
        

    4)
        ########################################
        # 🚀 Mise à jour des alias et des scripts"
        ########################################

         echo -e "\e[1;33m🔧 Étape 1 — Activation des scripts .sh dans Templates2\e[0m"
          SCRIPT_COUNT=$(find ~/NanaEparviers/api-mongo/Templates2/ -type f -name "*.sh" -exec chmod +x {} \; -print | wc -l)
          echo "✅ $SCRIPT_COUNT scripts .sh rendus exécutables"

          echo -e "\n\e[1;33m🔗 Étape 2 — Mise à jour des alias BernardOps\e[0m"
          if [ -f ~/generer_aliases.sh ]; then
            bash ~/generer_aliases.sh
            ALIAS_COUNT=$(grep -c "alias nana-" ~/NanaEparviers/api-mongo/Templates2/nana-aliases-all.txt)
            echo "✅ $ALIAS_COUNT alias BernardOps générés et activés"
          else
            echo "❌ Le script ~/generer_aliases.sh est introuvable."
            echo "💡 Tu peux le créer avec Copilot si besoin."
          fi

          echo -e "\n\e[1;32m🎯 Résumé BernardOps\e[0m"
          echo "────────────────────────────────────────────"
          echo "📜 Scripts activés : $SCRIPT_COUNT"
          echo "🔗 Alias disponibles : $ALIAS_COUNT"
          echo "🕒 Mise à jour effectuée le : $(date '+%Y-%m-%d %H:%M:%S')"

          echo -e "\n🔍 Derniers alias ajoutés :"
          tail -n 10 ~/NanaEparviers/api-mongo/Templates2/nana-aliases-all.txt | grep "alias nana-" | tail -n 5

          echo -e "\n🧩 Tous tes outils BernardOps sont prêts à l’emploi ✅"

          read -p "⏸️ Appuie sur Entrée pour revenir au menu..."
          ;;

    5)
        ########################################
        # ⬇️ Création d’un dépôt Git local + push intelligent"
        ########################################

          echo -e "\e[1;36m📝 BernardOps — Création d’une branche avec commit et push préparé\e[0m"
          echo "────────────────────────────────────────────"
          read -p "🔗 Nom du dépôt source (ex: user/repo) : " source_repo
          read -p "🌿 Nom de la nouvelle branche à créer : " new_branch
          read -p "📂 Nom du dossier local pour le clone : " clone_folder

          clone_path=~/"$clone_folder"

          if [ -d "$clone_path" ]; then
            echo "⚠️ Le dossier '$clone_folder' existe déjà."
            read -p "🧹 Le supprimer pour repartir propre ? (o/n) : " confirm
            [ "$confirm" = "o" ] && rm -rf "$clone_path"
          fi

          echo "📡 Clonage en cours depuis https://github.com/$source_repo.git..."
          git clone https://github.com/$source_repo.git "$clone_path" || {
            echo "❌ Échec du clonage."; read -p "⏎ Entrée..."; continue;
          }

          cd "$clone_path" || {
            echo "❌ Dossier introuvable après clonage."; read -p "⏎ Entrée..."; continue;
          }

            echo "🌿 Création ou activation de la branche '$new_branch'"
          if git show-ref --verify --quiet refs/heads/"$new_branch"; then
            git checkout "$new_branch"
            echo "✅ Branche existante activée."
          else
            git checkout -b "$new_branch"
            echo "✅ Nouvelle branche créée."
          fi

          read -p "🎯 Nom du dépôt cible (ex: user/repo) : " target_repo
          git remote set-url origin https://github.com/$target_repo.git
          echo "✅ Remote mis à jour."

          read -p "🔐 Utiliser SSH au lieu de HTTPS pour GitHub ? (o/n) : " use_ssh

          if [ "$use_ssh" = "o" ]; then
            ssh_key="$HOME/.ssh/id_rsa"
            if [ ! -f "$ssh_key" ]; then
              echo "🔐 Aucune clé SSH RSA trouvée. Génération d'une clé FIPS-compatible..."
              ssh-keygen -t rsa -b 3072 -f "$ssh_key" -N "" || {
                echo "❌ Échec de la génération de la clé SSH."; read -p "⏎ Entrée..."; continue;
              }
              echo "📋 Voici votre clé publique à ajouter sur GitHub :"
              cat "$ssh_key.pub"
              echo "🌐 Ajoutez-la ici : https://github.com/settings/keys"
              read -p "⏎ Appuie sur Entrée une fois la clé ajoutée..."
            fi

            echo "🔁 Passage à l’URL SSH pour GitHub"
            git remote set-url origin git@github.com:$target_repo.git
          else
            echo "🔁 Utilisation de l’URL HTTPS"
            git remote set-url origin https://github.com/$target_repo.git
          fi



          read -p "💬 Message du commit : " message
          git add .
          git commit -m "$message" && echo "✅ Commit enregistré." || echo "⚠️ Rien à commit."

          read -p "✅ Souhaitez-vous pousser cette branche vers GitHub ? (o/n) : " integrer
          if [ "$integrer" = "o" ]; then
            git push -u origin "$new_branch" && echo "✅ Branche poussée." || echo "❌ Échec du push."
          else
            echo "🧪 La branche reste en local pour l’instant."
          fi

          
              echo "📂 Dossier prêt : $clone_path"
          if command -v nautilus >/dev/null 2>&1; then
            nautilus "$clone_path" &
          else
            echo "🔍 Nautilus non disponible. Ouvre le dossier manuellement si besoin."
          fi

          read -p "⏎ Appuie sur Entrée pour revenir au menu..."
          ;;


    6)  
        ########################################
        # 🔀 Vérification clé SSH + FIPS + GRUB + RSA"
        ########################################  


        echo -e "\e[1;36m🔀 Option 6 — Vérification clé SSH + FIPS + GRUB + RSA\e[0m"
        echo "──────────────────────────────────────────────────────────────"

        echo "🔍 Test de la connexion SSH à GitHub..."
        ssh -T git@github.com 2>&1 | tee ssh_check.log

        if grep -q "successfully authenticated" ssh_check.log; then
          echo "✅ Connexion SSH réussie — ta clé est bonne"
        else
          echo "⚠️ Échec SSH — vérifie ta clé RSA"
          echo "🔗 https://github.com/settings/keys"
          echo "💡 ssh-add ~/.ssh/id_rsa"
        fi
        rm ssh_check.log

        echo -e "\n🔐 Vérification du mode FIPS sur ton système..."
        if [ -f /proc/sys/crypto/fips_enabled ]; then
          fips_status=$(cat /proc/sys/crypto/fips_enabled)
          if [ "$fips_status" = "1" ]; then
            echo "✅ Mode FIPS activé"
          else
            echo "❌ Mode FIPS désactivé"
          fi
        else
          echo "⚠️ Impossible de vérifier FIPS — fichier absent"
        fi

        echo -e "\n🔧 Vérification du support RSA dans OpenSSH..."
        ssh -Q key | grep rsa > /dev/null
        if [ $? -eq 0 ]; then
          echo "✅ RSA est supporté par OpenSSH"
        else
          echo "❌ RSA non supporté — FIPS peut bloquer les clés RSA"
        fi

        echo -e "\n🧠 Pour activer FIPS au démarrage via GRUB :"
        echo "  ➤ sudo grubby --update-kernel=ALL --args=fips=1"
        echo "  ➤ sudo dnf install dracut-fips"
        echo "  ➤ sudo dracut -f"
        echo "  ➤ sudo reboot"

        envoyer_mail_bernardops
        read -p "⏸️ Appuie sur Entrée pour revenir au menu..."
        ;;

   







    19)
      TITRE_OPTION="Journal de bord BernardOps"
      echo -e "\e[1;36m🗒️ Option 19 — $TITRE_OPTION\e[0m"
      echo "──────────────────────────────────────────────────────────────"

      JOURNAL="$HOME/BernardOps/journal_de_bord.txt"
      mkdir -p "$(dirname "$JOURNAL")"

      echo -e "\n📖 Voici ton journal de bord actuel :"
      if [ -s "$JOURNAL" ]; then
        cat "$JOURNAL"
      else
        echo "🕳️ Le journal est vide pour l’instant. Tu peux y inscrire ta première mission."
      fi

      echo -e "\n✍️ Souhaites-tu ajouter une nouvelle entrée ? (o/n)"
      read -r reponse
      if [[ "$reponse" == "o" || "$reponse" == "O" ]]; then
        echo "📝 Rédige ton entrée ci-dessous (finis par Ctrl+D) :"
        echo -e "\n🗓️ $(date '+%Y-%m-%d %H:%M:%S') — Nouvelle entrée :" >> "$JOURNAL"
        cat >> "$JOURNAL"
        echo -e "\n✅ Entrée ajoutée au journal de bord."
      fi

      echo "──────────────────────────────────────────────" >> "$JOURNAL"
      envoyer_mail_bernardops
      read -p "⏎ Appuie sur Entrée pour revenir au menu..."
      ;;

  esac
  echo ""
done

    


















































































































































