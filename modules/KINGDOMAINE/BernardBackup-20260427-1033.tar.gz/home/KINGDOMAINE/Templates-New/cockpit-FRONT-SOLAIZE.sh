#!/bin/bash

# 🧠 BernardOps — Pipeline .NET : pourquoi on fait RESTORE / BUILD / RUN / CLEAN / PUBLISH
# 1️⃣ dotnet restore  → Récupère les dépendances (NuGet). Prépare le terrain. Sans restore → build bancal.
# 2️⃣ dotnet build    → Compile le projet, vérifie les erreurs, génère bin/obj. Sans build → run instable.
# 3️⃣ dotnet run      → Lance l’app en mode dev, recharge auto, logs en direct. C’est ton mode de travail.
# 4️⃣ dotnet clean    → Supprime bin/obj, réinitialise. Utile si build cassé ou DLL corrompues.
# 5️⃣ dotnet publish  → Compile en Release, optimise, génère publish/. Version propre pour la production.



echo "🧠 BernardOps — Cockpit SolaizeFront (.NET Blazor Server)"
echo "────────────────────────────────────────────"

FRONT_DIR=~/EPARVIER/SolaizeCockpit/SolaizeFront

echo "📁 Projet : $FRONT_DIR"
echo "────────────────────────────────────────────"

echo "📋 MENU SOLAIZEFRONT (.NET)"
echo "1) Restaurer les dépendances (dotnet restore)"
echo "2) Build (dotnet build)"
echo "3) Lancer le front (dotnet run)"
echo "4) Nettoyer (dotnet clean)"
echo "5) Publier (dotnet publish)"
echo "0) Quitter"
echo "────────────────────────────────────────────"

read -p "👉 Choisis une option : " choix

case "$choix" in

  1)
    cd "$FRONT_DIR" || exit
    echo "📦 Restauration..."
    dotnet restore
    echo "✅ Restauration terminée"
    ;;

  2)
    cd "$FRONT_DIR" || exit
    echo "🏗️ Build..."
    dotnet build
    echo "✅ Build terminé"
    ;;

  3)
    cd "$FRONT_DIR" || exit
    echo "🚀 Lancement du front..."
    dotnet run
    ;;

  4)
    cd "$FRONT_DIR" || exit
    echo "🧹 Nettoyage..."
    dotnet clean
    echo "✅ Nettoyage terminé"
    ;;

  5)
    cd "$FRONT_DIR" || exit
    echo "📦 Publication..."
    dotnet publish -c Release -o publish
    echo "✅ Publication terminée"
    ;;

  0)
    echo "🧠 BernardOps terminé. Bon vol, Bernard 🐅"
    exit 0
    ;;

  *)
    echo "❌ Option inconnue"
    ;;
esac