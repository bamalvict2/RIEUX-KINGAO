#!/bin/bash

echo "🧠 BernardOps — nana-clean-status-merge.sh"
echo "────────────────────────────────────────────"

# Étape 0 : Vérifie les fichiers modifiés ou non suivis
echo "📦 Fichiers modifiés ou non suivis :"
git status --short

read -p "👉 Ajouter et committer ces fichiers avant de continuer ? (y/n) : " stage_ok
if [[ "$stage_ok" == "y" ]]; then
  git add -A
  read -p "📝 Message de commit : " commit_msg
  git commit -m "$commit_msg"
  echo "✅ Fichiers ajoutés et commités"
fi

echo "────────────────────────────────────────────"
# Étape 1 : Statut Git
echo "📊 Statut Git actuel :"
git status
echo "────────────────────────────────────────────"

read -p "👉 Continuer vers la fusion de branches ? (y/n) : " fusion_ok
if [[ "$fusion_ok" == "y" ]]; then
  current_branch=$(git branch --show-current)
  echo "📍 Branche actuelle : $current_branch"
  echo "🌿 Branches disponibles :"
  git branch --all | grep -v remotes | sed 's/..//'

  read -p "👉 Quelle branche veux-tu fusionner dans '$current_branch' ? " source_branch
  if git show-ref --verify --quiet refs/heads/"$source_branch"; then
    echo "🔄 Fusion de '$source_branch' dans '$current_branch'..."
    git merge "$source_branch"
    echo "✅ Fusion terminée"
    read -p "🚀 Pousser vers GitHub ? (y/n) : " push_ok
    [[ "$push_ok" == "y" ]] && git push
  else
    echo "❌ Branche '$source_branch' introuvable"
  fi
fi

echo "────────────────────────────────────────────"
read -p "🧹 Supprimer les branches locales déjà fusionnées ? (y/n) : " clean_ok
if [[ "$clean_ok" == "y" ]]; then
  echo "🔍 Suppression des branches locales fusionnées dans '$current_branch'..."
  git branch --merged | grep -v "\*" | grep -v "$current_branch" | while read branch; do
    echo "🗑️ Suppression : $branch"
    git branch -d "$branch"
  done
  echo "✅ Nettoyage terminé"
fi

echo "────────────────────────────────────────────"
read -p "📜 Afficher les 5 derniers commits ? (y/n) : " log_ok
if [[ "$log_ok" == "y" ]]; then
  echo "🧾 Derniers commits sur '$current_branch' :"
  git log -n 5 --oneline --graph --decorate
fi

echo "🧠 BernardOps terminé. Bon vol, Bernard 🐅"





echo "────────────────────────────────────────────"
read -p "📋 Afficher le pense-bête Git BernardOps ? (y/n) : " cheat_ok
if [[ "$cheat_ok" == "y" ]]; then
  echo "🔹 git status        ➤ Voir les fichiers modifiés"
  echo "🔹 git add -A        ➤ Ajouter tous les fichiers"
  echo "🔹 git commit -m     ➤ Créer un commit"
  echo "🔹 git push          ➤ Envoyer vers GitHub"
  echo "🔹 git pull          ➤ Récupérer les dernières modifs"
  echo "🔹 git branch        ➤ Voir les branches locales"
  echo "🔹 git merge         ➤ Fusionner une branche"
  echo "🔹 git log --oneline ➤ Historique visuel des commits"
fi