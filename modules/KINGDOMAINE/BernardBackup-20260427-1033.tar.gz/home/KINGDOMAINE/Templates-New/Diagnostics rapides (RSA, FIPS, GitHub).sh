#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🧩 Cockpit BernardOps — Diagnostics rapides (RSA, FIPS, GitHub)    ║
# ╚════════════════════════════════════════════════════════════════════╝

pause() {
  echo ""
  read -p "⏸️ Appuie sur Entrée pour valider et revenir au menu..."
}

LOG="$HOME/SolaizeBlazorServer/Templates3/diagnostics-rapides-$(date '+%Y%m%d-%H%M%S').log"
mkdir -p "$(dirname "$LOG")"
echo "🧠 Diagnostics rapides — $(date '+%Y-%m-%d %H:%M')" | tee "$LOG"

clear
figlet "DIAGNOSTICS RAPIDES" | lolcat
echo "──────────────────────────────────────────────"
echo "5️⃣ RSA Check"
echo "6️⃣ FIPS Check"
echo "7️⃣ GitHub SSH"
echo "8️⃣ Quitter"
echo "──────────────────────────────────────────────"

while true; do
  read -p "👉 Choisis le diagnostic à exécuter (ex: 5 6) : " CHOIX
  for num in $CHOIX; do
    case $num in
      5)
        figlet "RSA CHECK" | lolcat
        ssh -Q key | grep rsa && echo "✅ RSA supporté" | tee -a "$LOG" || echo "❌ RSA non disponible" | tee -a "$LOG"
        pause
        ;;
      6)
        figlet "FIPS CHECK" | lolcat
        cat /proc/sys/crypto/fips_enabled | grep 1 && echo "✅ FIPS activé" | tee -a "$LOG" || echo "❌ FIPS désactivé" | tee -a "$LOG"
        pause
        ;;
      7)
        figlet "GITHUB SSH" | lolcat
        ssh -T git@github.com 2>&1 | grep "successfully authenticated" && echo "✅ SSH GitHub OK" | tee -a "$LOG" || echo "❌ SSH GitHub KO" | tee -a "$LOG"
        pause
        ;;
      8)
        figlet "AU REVOIR PILOTE 👋" | lolcat
        echo "👋 Quitter le cockpit diagnostics." | tee -a "$LOG"
        exit 0
        ;;
      *)
        echo "❌ Option inconnue : $num" | tee -a "$LOG"
        pause
        ;;
    esac
  done
done