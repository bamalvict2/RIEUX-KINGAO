#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🖥️ BernardOps — Système Cockpit                                    ║
# ║ Menu dédié aux vérifications système et diagnostics rapides        ║
# ╚════════════════════════════════════════════════════════════════════╝

pause() {
  echo ""
  read -p "⏸️ Appuie sur Entrée pour revenir au menu..."
}

while true; do
  clear
  figlet "SYSTEME" | lolcat
  echo "──────────────────────────────────────────────"
  echo "1️⃣ Health check"
  echo "2️⃣ Logs système"
  echo "3️⃣ Diagnostics rapides 🧩"
  echo "4️⃣ Retour menu principal"
  echo "──────────────────────────────────────────────"

  read -p "👉 Choix: " choix
  case $choix in
    1)
      echo "🔎 Health check en cours..."
      # Exemple simple : uptime + mémoire
      echo "⏱️ Uptime:"; uptime
      echo "💾 Mémoire:"; free -h
      pause
      ;;
    2)
      echo "📜 Logs système"
      read -p "👉 Entre le nom du service (ex: NetworkManager, ssh, docker): " service
      if [[ -n "$service" ]]; then
        echo "📜 Logs du service $service (20 dernières lignes)"
        journalctl -u "$service" -n 20 --no-pager
      else
        echo "📜 Logs système (20 dernières lignes globales)"
        journalctl -n 20 --no-pager
      fi
      pausecho "📜 Affichage des logs système..." 
      ;;
    3)
      echo "🧩 Lancement des diagnostics rapides..."
      bash ~/SolaizeBlazorServer/Templates2/diagnostics-rapides.sh
      pause   
      ;;
    4)
      echo "👋 Retour au cockpit principal"
      exit 0
      ;;
    *)
      echo "⚠️ Choix invalide, réessaie."
      pause
      ;;
  esac
done