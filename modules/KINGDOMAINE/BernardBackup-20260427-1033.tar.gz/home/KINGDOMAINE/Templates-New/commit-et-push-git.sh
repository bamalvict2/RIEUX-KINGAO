
while true; do
  echo "=== 🌀 BernardOps — Menu Git ==="
  echo "1) Status"
  echo "2) Log (graph)"
  echo "3) Gestion des remotes"
  echo "q) Retour au cockpit principal"

  read -p "Choix Git: " choix_git
  case $choix_git in
    1) git status ;;
    2) git log --graph --oneline --decorate --all ;;
    3) bash ./remote-menu.sh ;;   # ton menu Remote séparé
    q) echo "↩️ Retour au cockpit principal"; break ;;
    *) echo "⚠️ Choix invalide" ;;
  esac
done

