#!/bin/bash
# 🧠 Restauration d’une configuration GRUB sauvegardée
# Horodatage : $(date '+%Y-%m-%d_%H:%M')

DEST="$HOME/NanaBackups/GRUB"
echo "🧠 Dossier des backups GRUB : $DEST"

# Liste les fichiers disponibles
echo "📂 Backups disponibles :"
ls -1 "$DEST"/grub-*.backup

# Demande à l’utilisateur de choisir un fichier
read -p "🧠 Entrez le nom du fichier à restaurer (sans chemin) : " FILENAME
BACKUP="$DEST/$FILENAME"

# Vérifie que le fichier existe
if [ ! -f "$BACKUP" ]; then
    echo "❌ Fichier introuvable : $BACKUP"
    exit 1
fi

# Copie le fichier vers /etc/default/grub
echo "🧠 Restauration en cours → /etc/default/grub"
sudo cp "$BACKUP" /etc/default/grub

# Recharge GRUB
echo "🧠 Mise à jour de GRUB..."
sudo update-grub

echo "✅ GRUB restauré depuis : $BACKUP"