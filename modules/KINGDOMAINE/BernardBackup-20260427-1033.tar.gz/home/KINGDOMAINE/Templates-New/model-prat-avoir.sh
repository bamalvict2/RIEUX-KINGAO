#!/bin/bash

while true; do
  clear
  echo -e "\e[1;36m🧠 BernardOps — Menu de vérification du déploiement\e[0m"
  echo "────────────────────────────────────────────────────"
  echo "1️⃣  Vérifier les pods"
  echo "2️⃣  Voir les logs des pods KO"
  echo "3️⃣  Vérifier les services"
  echo "4️⃣  Vérifier l’ingress"
  echo "5️⃣  Vérifier le controller NGINX"
  echo "6️⃣  Vérifier l’image Docker"
  echo "7️⃣  Vérifier buildx"
  echo "8️⃣  Vérifier MongoDB"
  echo "9️⃣  Tester l’API REST"
  echo "🔟  Vérifier DNS FreeDNS"
  echo "0️⃣  Quitter"
  echo "────────────────────────────────────────────────────"
  read -p "🧭 Choisis une option : " choice

  case $choice in
    1) echo -e "\n🔍 Pods"; kubectl get pods; read -p "⏸️ Entrée pour continuer..." ;;
    2) echo -e "\n🪵 Logs pods KO"; kubectl get pods | grep -v Running | awk '{print $1}' | while read pod; do echo -e "\n📋 Logs pour $pod"; kubectl logs "$pod" --all-containers=true; done; read -p "⏸️ Entrée pour continuer..." ;;
    3) echo -e "\n🔗 Services"; kubectl get svc; read -p "⏸️ Entrée pour continuer..." ;;
    4) echo -e "\n🚪 Ingress"; kubectl get ingress; kubectl describe ingress nana-api-ingress; read -p "⏸️ Entrée pour continuer..." ;;
    5) echo -e "\n🧬 Controller NGINX"; kubectl get pods -n ingress-nginx; kubectl describe pod -n ingress-nginx $(kubectl get pods -n ingress-nginx | grep controller | awk '{print $1}'); read -p "⏸️ Entrée pour continuer..." ;;
    6) echo -e "\n🧱 Image Docker"; docker images | grep api-mongo; read -p "⏸️ Entrée pour continuer..." ;;
    7) echo -e "\n🔧 Buildx"; docker buildx ls; read -p "⏸️ Entrée pour continuer..." ;;
    8) echo -e "\n🧠 MongoDB"; kubectl get pods | grep mongodb; kubectl logs $(kubectl get pods | grep mongodb | awk '{print $1}'); read -p "⏸️ Entrée pour continuer..." ;;
    9) echo -e "\n🧪 Test API"; curl -i http://localhost/api/eparviers; read -p "⏸️ Entrée pour continuer..." ;;
    10) echo -e "\n🌐 DNS FreeDNS"; cat ~/NanaEparviers/api-mongo/dns-update.log; read -p "⏸️ Entrée pour continuer..." ;;
    0) echo "🚪 Sortie du menu BernardOps"; break ;;
    *) echo "❌ Option invalide"; sleep 1 ;;
  esac
done