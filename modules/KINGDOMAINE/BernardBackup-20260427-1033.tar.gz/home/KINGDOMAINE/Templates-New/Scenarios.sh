########################################
# 🔄 Pull + Commit + Push
########################################
scenario_pull_push() {
  echo "=== 🔄 Pull + Commit + Push ==="
  # Vérification propreté locale
  if ! git diff --cached --quiet || ! git diff --quiet; then
    echo "⚠️ Modifications non commitées détectées, commit obligatoire avant pull/push."
  fi
  git_pull_repo
  read -p "Message commit: " MSG
  git add .
  git commit -m "$MSG"
  git_push_repo
  echo "✅ Pull + Commit + Push terminé"
}

########################################
# ⚠️ Force Push
########################################
scenario_force_push() {
  echo "=== ⚠️ Force Push ==="
  read -p "Branche locale: " LOCAL
  read -p "Branche distante: " REMOTE
  echo "⚠️ Attention : tu vas écraser l’historique du hub."
  read -p "Confirmer (oui/non): " CONFIRM
  if [ "$CONFIRM" = "oui" ]; then
    git push origin "$LOCAL:$REMOTE" --force
    echo "✅ Force Push effectué"
  else
    echo "❌ Force Push annulé"
  fi
}

########################################
# ⏪ Rollback dernier commit
########################################
scenario_rollback_last_commit() {
  echo "=== ⏪ Rollback dernier commit ==="
  echo "⚠️ Attention : cette action est destructive."
  git log -1 --oneline
  read -p "Confirmer rollback (oui/non): " CONFIRM
  if [ "$CONFIRM" = "oui" ]; then
    git reset --hard HEAD~1
    echo "✅ Rollback effectué"
  else
    echo "❌ Rollback annulé"
  fi
}