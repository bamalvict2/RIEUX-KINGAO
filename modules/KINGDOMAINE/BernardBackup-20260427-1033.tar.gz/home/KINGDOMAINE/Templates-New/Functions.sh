########################################
# 📥 Clone un repo (avec branche)
########################################
git_clone_repo() {
  read -p "URL du repo (SSH recommandé): " REPO
  read -p "Branche: " BRANCH
  echo "🌐 Vérification du dépôt distant..."
  if ! git ls-remote "$REPO" &>/dev/null; then
    echo "❌ Dépôt inaccessible ou inexistant sur le hub."
    return 1
  fi
  git clone -b "$BRANCH" "$REPO"
  [ $? -eq 0 ] && echo "✅ Repo cloné (branche $BRANCH)" || echo "❌ Erreur clonage"
}

########################################
# ⬇️ Pull hub → local
########################################
git_pull_repo() {
  read -p "Branche à pull: " BRANCH
  # Vérification propreté locale
  if ! git diff --cached --quiet || ! git diff --quiet; then
    echo "⚠️ Modifications non commitées détectées, commit obligatoire avant pull."
    return 1
  fi
  if ! git ls-remote origin &>/dev/null; then
    echo "❌ Remote 'origin' inaccessible ou inexistant."
    return 1
  fi
  git pull origin "$BRANCH"
  [ $? -eq 0 ] && echo "✅ Pull réussi depuis $BRANCH" || echo "❌ Erreur pull"
}

########################################
# ⬆️ Push local → hub
########################################
git_push_repo() {
  read -p "Branche locale: " LOCAL
  read -p "Branche distante: " REMOTE
  if ! git diff --cached --quiet || ! git diff --quiet; then
    echo "⚠️ Modifications non commitées détectées, commit obligatoire avant push."
    return 1
  fi
  if ! git ls-remote origin &>/dev/null; then
    echo "❌ Remote 'origin' inaccessible ou inexistant."
    return 1
  fi
  echo "⚠️ Vérification divergence entre local et distant..."
  git fetch origin "$REMOTE"
  if git show-ref --verify --quiet refs/remotes/origin/$REMOTE; then
    if [ -z "$(git log origin/$REMOTE..$LOCAL --oneline)" ]; then
      echo "ℹ️ Aucun changement à pousser : $LOCAL → $REMOTE identiques"
    else
      echo "⚠️ Divergence détectée, choisis : (m) merge, (f) force, (l) force-with-lease"
      read -p "Ton choix: " CHOIX
      case $CHOIX in
        m) git pull origin "$REMOTE" && git push origin "$LOCAL:$REMOTE" ;;
        f) git push origin "$LOCAL:$REMOTE" --force ;;
        l) git push origin "$LOCAL:$REMOTE" --force-with-lease ;;
        *) echo "❌ Choix invalide, push annulé" ;;
      esac
    fi
  else
    echo "⚠️ La branche distante '$REMOTE' n’existe pas encore."
    git push -u origin "$LOCAL:$REMOTE"
  fi
}