#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🚀 BernardOps — Cockpit Principal (Templates2 figé)                ║
# ║ Point d’entrée unique, route les sous-menus spécialisés            ║
# ╚════════════════════════════════════════════════════════════════════╝

# === Chargement des fonctions génériques ===
source ./Functions.sh
source ./Scenarios.sh

# === Vérification des modules locaux ===
for script in docker-cockpit.sh git-cockpit.sh system-cockpit.sh cockpit-auth.sh cockpit-diagnostics.sh; do
  if [[ -f ~/SolaizeBlazorServer/Templates2/$script ]]; then
    echo "✅ $script disponible"
  else
    echo "❌ $script manquant"
  fi
done

# === Aliases ergonomiques ===
alias nana-docker="bash ~/EPARVIER/Templates-new/docker-cockpit.sh"     # 🐳 Docker cockpit
alias nana-git="bash ~/EPARVIER/Templates-new/git-cockpit.sh"           # 🔧 Git cockpit
alias nana-system="bash ~/EPARVIER/Templates-new/system-cockpit.sh"     # 🖥️ Système cockpit
alias nana-auth="bash ~/EPARVIER/Templates-new/cockpit-auth.sh"         # 🔐 Auth cockpit
alias nana-diag="bash ~/EPARVIER/Templates-new/cockpit-diagnostics.sh"  # 🧩 Diagnostics rapides

# === Boucle principale ===
while true; do
  echo "=== 🚀 BernardOps — Cockpit Principal ==="
  echo "1) Docker 🐳"
  echo "2) Git 🔧"
  echo "3) Système 🖥️"
  echo "4) Auth 🔐"
  echo "5) Diagnostics rapides 🧩"
  echo "6) Quitter"

  read -p "Choix: " choix
  case $choix in
    1) bash ./docker-cockpit.sh ;;        # Sous-menu Docker
    2) bash ./git-cockpit.sh ;;           # Sous-menu Git
    3) bash ./system-cockpit.sh ;;        # Sous-menu Système
    4) bash ./cockpit-auth.sh ;;          # Sous-menu Auth
    5) bash ./cockpit-diagnostics.sh ;;   # Sous-menu Diagnostics rapides
    6) echo "👋 Au revoir BernardOps"; exit ;;
    *) echo "⚠️ Choix invalide, réessaie." ;;
  esac
done



 Templates2.sh (Menu principal)
 │
 ├── 1) Docker  🐳 nana-docker
 │    └── docker-cockpit.sh
 │         ├── Start services
 │         ├── Stop services
 │         ├── Status
 │         └── Retour menu principal
 │
 ├── 2) Git  🔧 nana-git
 │    └── git-cockpit.sh
 │         ├── 1) Fonctions de base → git-fct.sh
 │         │    ├── Cloner un repo
 │         │    ├── Pull / Push / Status
 │         │    ├── Log (graph)
 │         │    └── Changer de branche
 │         │
 │         ├── 2) Scénarios → git-scenarios.sh
 │         │    ├── Pull + Commit + Push
 │         │    ├── Force Push
 │         │    └── Rollback dernier commit
 │         │
 │         ├── 3) Remote → git-remote.sh
 │         │    ├── Lister les remotes
 │         │    ├── Ajouter / Supprimer / Modifier remote
 │         │    └── Vérifier connexion SSH
 │         │
 │         └── 4) Auth → git-auth.sh
 │              ├── Vérification FIPS
 │              └── Vérification RSA SSH
 │
 ├── 3) Système  🖥️ nana-system
 │    └── system-cockpit.sh
 │         ├── Health check
 │         ├── Logs système
 │         └── Retour menu principal
 │
 ├── 4) Auth 🔐 nana-auth
 │    └── cockpit-auth.sh
 │         ├── Login
 │         ├── Token refresh
 │         └── Retour menu principal
 │
 ├── 5) Diagnostics rapides 🧩 nana-diag
 │    └── cockpit-diagnostics.sh
 │         ├── RSA Check
 │         ├── FIPS Check
 │         ├── GitHub SSH
 │         └── Quitter diagnostics
 │
 └── 6) Quitter