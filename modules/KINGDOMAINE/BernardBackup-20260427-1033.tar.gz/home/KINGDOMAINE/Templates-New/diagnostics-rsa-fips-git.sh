#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🧩 Cockpit BernardOps — Diagnostics rapides (RSA, FIPS, GitHub)    ║
# ╚════════════════════════════════════════════════════════════════════╝

pause() {
  echo ""
  read -p "⏸️ Appuie sur Entrée pour valider et revenir au menu..."
}

# Log principal (Templates2)
LOG="$HOME/SolaizeBlazorServer/Templates2/diagnostics-rapides-$(date '+%Y%m%d-%H%M%S').log"

# Log secondaire (Templates3/Resultats)
LOG2="$HOME/SolaizeBlazorServer/Templates4/Resultats-SSH/diag-rapides-$(date '+%Y%m%d-%H%M%S').log"

# Création des répertoires si besoin
mkdir -p "$(dirname "$LOG")"
mkdir -p "$(dirname "$LOG2")"

echo "🧠 Diagnostics rapides — $(date '+%Y-%m-%d %H:%M')" | tee "$LOG" | tee "$LOG2"

clear
figlet "DIAGNOSTICS RAPIDES" | lolcat
echo "──────────────────────────────────────────────"
echo "5️⃣ RSA Check"
echo "6️⃣ FIPS Check"
echo "7️⃣ GitHub SSH"
echo "8️⃣ Quitter"
echo "──────────────────────────────────────────────"

while true; do
  read -p "👉 Choisis le diagnostic à exécuter (ex: 5 6) : " CHOIX
  for num in $CHOIX; do
    case $num in
      5)
        figlet "RSA CHECK" | lolcat
        ssh -Q key | grep rsa \
          && echo "✅ RSA supporté" | tee -a "$LOG" | tee -a "$LOG2" \
          || echo "❌ RSA non disponible" | tee -a "$LOG" | tee -a "$LOG2"
        pause
        ;;
      6)
        figlet "FIPS CHECK" | lolcat
        cat /proc/sys/crypto/fips_enabled | grep 1 \
          && echo "✅ FIPS activé" | tee -a "$LOG" | tee -a "$LOG2" \
          || echo "❌ FIPS désactivé" | tee -a "$LOG" | tee -a "$LOG2"
        pause
        ;;
      7)
        figlet "GITHUB SSH" | lolcat
        ssh -T git@github.com 2>&1 | grep "successfully authenticated" \
          && echo "✅ SSH GitHub OK" | tee -a "$LOG" | tee -a "$LOG2" \
          || echo "❌ SSH GitHub KO" | tee -a "$LOG" | tee -a "$LOG2"
        pause
        ;;
      8)
        figlet "AU REVOIR PILOTE 👋" | lolcat
        echo "👋 Quitter le cockpit diagnostics." | tee -a "$LOG" | tee -a "$LOG2"
        exit 0
        ;;
      *)
        echo "❌ Option inconnue : $num" | tee -a "$LOG" | tee -a "$LOG2"
        pause
        ;;
    esac
  done
done