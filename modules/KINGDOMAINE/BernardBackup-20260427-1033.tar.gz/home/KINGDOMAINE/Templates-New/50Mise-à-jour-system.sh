#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🧩 mise-a-jour-systeme.sh — Choix par numéro cockpitifié           ║
# ╚════════════════════════════════════════════════════════════════════╝

LOG="$HOME/cockpit/logs/mise-a-jour-systeme-$(date '+%Y%m%d-%H%M%S').log"
mkdir -p "$(dirname "$LOG")"
echo "🧠 Mise à jour système cockpitifiée — $(date '+%Y-%m-%d %H:%M')" | tee "$LOG"

# ╭────────────────────────────────────────────────────────────╮
# │ 🧩 Menu cockpitifié par numéro                             │
# ╰────────────────────────────────────────────────────────────╯
echo -e "\n🧩 Modules disponibles :"
echo "  [1] Installation des outils pro (VS Code, Docker, Node.js...)"
echo "  [2] Rendre exécutables les scripts .sh dans Templates2"
echo "  [3] Nettoyage BernardOps modulaire (--menu)"
echo "  [4] Quitter"

read -p "👉 Choisis les modules à exécuter (ex: 1 2) : " CHOIX

for num in $CHOIX; do
  case $num in

    1)
      echo "📦 [1] Installation des outils pro..." | tee -a "$LOG"

      # 🔍 Détection VS Code sources malformées
      if [[ -f /etc/apt/sources.list.d/vscode.sources ]]; then
        echo "⚠️ vscode.sources malformé détecté. Suppression cockpitifiée..." | tee -a "$LOG"
        sudo rm /etc/apt/sources.list.d/vscode.sources
      fi

      # 🔁 Suppression du dépôt dupliqué
      if [[ -f /etc/apt/sources.list.d/vscode.list ]]; then
        echo "⚠️ vscode.list déjà présent. Suppression pour recréation propre..." | tee -a "$LOG"
        sudo rm /etc/apt/sources.list.d/vscode.list
      fi

      # ✅ Recréation du dépôt VS Code dans un fichier .list
      echo "deb [arch=amd64] https://packages.microsoft.com/repos/code stable main" | sudo tee /etc/apt/sources.list.d/vscode.list

      # 🧪 Réparation dpkg si nécessaire
      echo "🧪 Vérification des paquets cassés..." | tee -a "$LOG"
      sudo dpkg --configure -a
      sudo apt --fix-broken install -y

      # 📦 Mise à jour des dépôts
      sudo apt update >> "$LOG"

      # 📦 Installation des outils de base
      sudo apt install -y curl wget git make build-essential gpg unzip >> "$LOG"

      # 📦 Installation de VS Code
      wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
      sudo install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/
      sudo apt install -y code >> "$LOG"

      # 📦 Installation de Thunderbird
      sudo apt install -y thunderbird >> "$LOG"

      # 📦 Installation de Docker + Compose
      sudo apt install -y docker.io docker-compose >> "$LOG"
      sudo systemctl enable docker >> "$LOG"
      sudo usermod -aG docker $USER

      # 📦 Installation de Node.js + npm
      sudo apt install -y nodejs npm >> "$LOG"

      # 🔍 Vérification MongoDB client
      if apt-cache show mongodb-clients >/dev/null 2>&1; then
        echo "📦 Installation de mongodb-clients..." | tee -a "$LOG"
        sudo apt install -y mongodb-clients >> "$LOG"
      elif apt-cache show mongodb-clients-core >/dev/null 2>&1; then
        echo "📦 mongodb-clients introuvable. Installation de mongodb-clients-core..." | tee -a "$LOG"
        sudo apt install -y mongodb-clients-core >> "$LOG"
      else
        echo "❌ Aucun paquet MongoDB client trouvé. Installation via Snap recommandée." | tee -a "$LOG"
        echo "📦 Commande cockpit : sudo snap install mongosh" | tee -a "$LOG"
      fi

      # 📦 Installation des outils VMware
      sudo apt install -y open-vm-tools open-vm-tools-desktop >> "$LOG"

      echo "✅ Outils pro installés." | tee -a "$LOG"
      ;;



    2)
      echo "🛠️ [2] Validation des scripts .sh dans Templates2..." | tee -a "$LOG"
      TARGET_DIR="$HOME/NanaEparviers/api-mongo/Templates2"
      NON_EXEC=$(find "$TARGET_DIR" -type f -name "*.sh" ! -executable)
      if [[ -z "$NON_EXEC" ]]; then
        echo "✅ Tous les scripts sont déjà exécutables." | tee -a "$LOG"
      else
        for file in $NON_EXEC; do
          chmod +x "$file"
          echo "✅ chmod +x : $file" | tee -a "$LOG"
        done
      fi
      ;;
    3)
      echo "🧹 [3] Nettoyage BernardOps modulaire..." | tee -a "$LOG"
      "$HOME/NanaEparviers/api-mongo/Templates2/clean-bernardops-modulaire.sh" --menu
      ;;
    4)
      echo "👋 Quitter le cockpit." | tee -a "$LOG"
      exit 0
      ;;
    *)
      echo "❌ Option inconnue : $num" | tee -a "$LOG"
      ;;


    5)  

        #!/bin/bash
      # ╔════════════════════════════════════════════════════════════════════╗
      # ║ 🧠 repair-grub-fips.sh — Corrige GRUB cassé par ubuntu-fips        ║
      # ╚════════════════════════════════════════════════════════════════════╝

      LOG="$HOME/cockpit/logs/repair-grub-fips-$(date '+%Y%m%d-%H%M%S').log"
      mkdir -p "$(dirname "$LOG")"
      echo "🧠 Réparation GRUB FIPS — $(date '+%Y-%m-%d %H:%M')" | tee "$LOG"

      # 🔍 Vérifie si la ligne fautive existe
      FAULTY_LINE=$(grep -E 'root=UUID=\$\(' /etc/grub.d/40_custom)

      if [[ -n "$FAULTY_LINE" ]]; then
        echo "⚠️ Ligne GRUB dynamique détectée : substitution shell non supportée." | tee -a "$LOG"

        # 🔍 Extraction du périphérique utilisé
        DEVICE=$(echo "$FAULTY_LINE" | grep -o '/dev/sd[a-z][0-9]')

        if [[ -z "$DEVICE" ]]; then
          echo "❌ Impossible d'extraire le périphérique. Abandon cockpitifié." | tee -a "$LOG"
          exit 1
        fi

        # 🔍 Extraction de l'UUID réel
        UUID=$(blkid -s UUID -o value "$DEVICE")
        if [[ -z "$UUID" ]]; then
          echo "❌ UUID introuvable pour $DEVICE. Abandon cockpitifié." | tee -a "$LOG"
          exit 1
        fi

        # 🛠️ Remplacement dans le fichier GRUB
        echo "🔁 Remplacement de la ligne fautive par UUID statique : $UUID" | tee -a "$LOG"
        sudo sed -i "s|root=UUID=\$(blkid -s UUID -o value $DEVICE)|root=UUID=$UUID|g" /etc/grub.d/40_custom

        # 🔄 Régénération GRUB
        echo "🔧 Régénération GRUB..." | tee -a "$LOG"
        sudo update-grub >> "$LOG"

        # 🔁 Relance dpkg
        echo "🔧 Relance dpkg pour finaliser ubuntu-fips..." | tee -a "$LOG"
        sudo dpkg --configure -a >> "$LOG"

        echo "✅ GRUB réparé et dpkg débloqué." | tee -a "$LOG"
      else
        echo "✅ Aucun problème détecté dans /etc/grub.d/40_custom." | tee -a "$LOG"
      fi
      ;;



  esac
done

echo "📦 Mise à jour terminée. Log : $LOG"