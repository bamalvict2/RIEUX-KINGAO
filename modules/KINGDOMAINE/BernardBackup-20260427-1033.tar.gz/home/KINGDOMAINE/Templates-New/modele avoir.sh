#!/bin/bash
SCRIPT_PATH="/home/bamalvict/cockpit/70Methode-Cron-Explication-creation.sh"

while true; do
  echo "──────────────────────────────────────────────"
  echo "📋 Menu Cockpit — Script en live : $SCRIPT_PATH"
  echo "1️⃣ Créer le script"
  echo "2️⃣ Rendre exécutable"
  echo "3️⃣ Lancer manuellement"
  echo "4️⃣ Ajouter au démarrage (cron)"
  echo "5️⃣ Vérifier crontab"
  echo "6️⃣ Consulter les logs"
  echo "7️⃣ ⚠️ Action dangereuse avec sudo"
  echo "8️⃣ Tester immédiatement le cron (simulation)"
  echo "9️⃣ Aller dans le dossier cockpit (terminal)"
  echo "🔟 Supprimer un script (.sh)"
  echo "1️⃣1️⃣ Ouvrir cockpit dans Nautilus"
  echo "1️⃣2️⃣ Ouvrir un script dans gedit"
  echo "0️⃣ Quitter"
  echo "──────────────────────────────────────────────"
  read -p "👉 Ton choix : " choix

  case $choix in
    1) nano "$SCRIPT_PATH" ;;
    2) chmod +x "$SCRIPT_PATH" ;;
    3) bash "$SCRIPT_PATH" ;;
    4) echo "@reboot $SCRIPT_PATH" ;;
    5) crontab -l ;;
    6) grep CRON /var/log/syslog ; journalctl -u cron ;;
    7)
      echo "⚠️ ATTENTION : tu vas lancer une vraie commande système."
      read -p "👉 Confirme avec OUI pour continuer : " confirm
      if [[ "$confirm" == "OUI" ]]; then
        sudo apt update && sudo apt upgrade -y
      else
        echo "❌ Action annulée."
      fi
      ;;
    8) bash "$SCRIPT_PATH" ;;
    9) cd ~/cockpit && ls -lh *.sh ;;
    10)
      cd ~/cockpit
      echo "📂 Scripts disponibles :"
      ls -lh *.sh
      read -p "👉 Nom du script à supprimer : " del
      if [[ -n "$del" && -f "$del" ]]; then
        read -p "⚠️ Confirme avec OUI pour supprimer $del : " confirm
        if [[ "$confirm" == "OUI" ]]; then
          rm "$del"
          echo "✅ $del supprimé."
        else
          echo "❌ Suppression annulée."
        fi
      else
        echo "❌ Fichier introuvable."
      fi
      ;;
    11) nautilus ~/cockpit & ;;
    12)
      cd ~/cockpit
      echo "📂 Scripts disponibles :"
      ls -lh *.sh
      read -p "👉 Nom du script à ouvrir dans gedit : " edit
      if [[ -n "$edit" && -f "$edit" ]]; then
        gedit "$edit" &
        echo "✅ $edit ouvert dans gedit."
      else
        echo "❌ Fichier introuvable."
      fi
      ;;
    0) echo "👋 Fin du menu cockpit." ; break ;;
    *) echo "❌ Choix invalide, réessaie." ;;
  esac
done