#!/bin/bash
# BernardOps — Cockpit unifié
# Git + Post-déploiement + API .NET8

# Mémo DTO Images — BernardOps




#🚀 Avantages cockpitifiés
• 	src/ → tout ton code applicatif (API, MAUI, Blazor, DTO).
• 	cockpit/ → tes scripts Bash, menus, helpers.
• 	yaml/ → tes déploiements Docker/K8s, bien séparés.
• 	docs/ → tes mémos et guides pédagogiques.
• 	tests/ → tu gardes une zone claire pour valider ton code.
• 	data/ → persistance MongoDB, isolée.


SolaizeServer/
│
├── src/                     # Code source principal
│   ├── Api/                 # Projet .NET8 Web API
│   │   └── Api.csproj
│   ├── MauiApp/             # Projet MAUI (Android/iOS/Windows)
│   │   └── MauiApp.csproj
│   ├── BlazorApp/           # Projet Blazor (si besoin)
│   │   └── BlazorApp.csproj
│   └── SharedModels/        # DTO, classes partagées
│       └── SharedModels.csproj
│
├── cockpit/                 # Scripts Bash cockpitifiés
│   ├── cockpit.sh           # Menu unifié
│   └── helpers.sh           # Fonctions utilitaires
│
├── yaml/                    # Déploiements Docker/K8s
│   ├── grafana-compose.yml
│   ├── prometheus-compose.yml
│   ├── mongo-compose.yml
│   └── k8s/                 # Manifests Kubernetes
│       ├── deployment.yaml
│       └── service.yaml
│
├── docs/                    # Documentation ergonomique
│   ├── memo-git.md
│   ├── memo-images.md
│   └── workflow.md
│
├── tests/                   # Tests unitaires et intégration
│   └── ApiTests/
│
└── data/                    # Données persistantes
    └── mongo/               # Volume MongoDB


## Upload
- Commande cockpit (option 19) → demande un chemin vers ton image locale.
- Exemple : ~/Pictures/test.png
- Le cockpit envoie l’image à ton API via `curl -F "file=@image.png"`.

## Download
- Commande cockpit (option 19) → récupère une image par son ID.
- Exemple : `curl http://localhost:5000/api/images/123`
- L’API renvoie ton DTO avec métadonnées (Id, FileName, ContentType, Url/Data).

## DTO utilisé
public class ImageDto {
    public string Id { get; set; }
    public string FileName { get; set; }
    public string ContentType { get; set; }
    public string Url { get; set; } // ou byte[] Data
}

## Notes
- Stockage possible en MongoDB (GridFS ou URL).
- Front MAUI/Blazor consomme directement ce DTO.
- Cockpit sert de guide pour tester rapidement upload/download.


echo -e "\033[1;34m=== BernardOps — Cockpit BernardOps ===\033[0m"
echo "1) Cloner un repo (avec branche et push préparé)"
echo "2) Pull (source/destination)"
echo "3) Push (source/destination)"
echo "4) Status"
echo "5) Log (graph)"
echo "6) Lister les remotes"
echo "7) Changer de branche"
echo "8) Mémo Git"
echo "9) Lancer Grafana"
echo "10) Lancer Prometheus"
echo "11) Lancer MongoDB"
echo "12) Vérifier containers actifs"
echo "13) Logs d’un service"
echo "14) Arrêter un service"
echo "15) Mémo Post (Docker/K8s)"
echo "16) Build API .NET8 en exécutable"
echo "17) Déployer API sur Firebase (Cloud Run)"
echo "18) Packager API pour Android (MAUI/Blazor)"
echo "19) Test DTO Images (upload/download)"
echo "20) Start cockpit complet (Grafana + Prometheus + MongoDB)"

read -p "Choix: " choix

case $choix in
  # --- Git options (1 à 8) ---
  1) echo "Clone + branche + push préparé";;
  2) echo "Pull SRC/DEST";;
  3) echo "Push SRC/DEST";;
  4) git status ;;
  5) git log --oneline --graph --decorate --all ;;
  6) git remote -v ;;
  7)
    echo "Branches locales :"; git branch
    echo "Branches distantes :"; git ls-remote --heads origin
    read -p "🌿 Nom de la branche : " BRANCH
    if git show-ref --verify --quiet refs/heads/$BRANCH; then
      git checkout $BRANCH
    else
      read -p "Créer la branche ? (o/n): " confirm
      [ "$confirm" = "o" ] && git checkout -b $BRANCH
    fi
    ;;
  8)
    echo "📖 Mémo Git"
    echo "git branch / git branch -vv"
    echo "git ls-remote --heads origin"
    echo "git checkout <branch>"
    echo "git checkout -b <branch>"
    echo "git push -u origin <branch>"
    echo "git fetch origin && git checkout -b <branch> origin/<branch>"
    ;;
  # --- Post options (9 à 15) ---
  9) docker-compose -f yaml/grafana-compose.yml up -d ;;
  10) docker-compose -f yaml/prometheus-compose.yml up -d ;;
  11) docker-compose -f yaml/mongo-compose.yml up -d ;;
  12) docker ps ;;
  13) read -p "Nom du service : " service; docker logs -f $service ;;
  14) read -p "Nom du service à arrêter : " service; docker stop $service ;;
  15)
    echo "📖 Mémo Post"
    echo "Lister containers : docker ps"
    echo "Arrêter un container : docker stop <id|nom>"
    echo "Relancer un service : docker-compose up -d"
    echo "Inspecter logs : docker logs -f <service>"
    ;;
  # --- API .NET8 options (16 à 18) ---
  16)
    echo "🚀 Build API .NET8 en exécutable self-contained"
    read -p "Chemin du projet API : " proj
    dotnet publish $proj -c Release -r linux-x64 --self-contained true
    ;;
  17)
    echo "🚀 Déploiement API sur Firebase (Cloud Run)"
    read -p "Nom du service : " service
    gcloud run deploy $service --source .
    ;;
  18)
    echo "🚀 Packager API pour Android (MAUI/Blazor)"
    read -p "Chemin du projet MAUI : " proj
    dotnet build $proj -t:Run -f net8.0-android


  19)
    echo "🚀 Test DTO Images"
    echo "Upload d’une image via API"
    read -p "Chemin du fichier image : " img
    curl -X POST http://localhost:5000/api/images \
      -H "Content-Type: multipart/form-data" \
      -F "file=@$img"
    echo "📥 Download d’une image (exemple avec ID=123)"
    curl http://localhost:5000/api/images/123
    ;;
  20)
    echo "🚀 Démarrage cockpit complet (Grafana + Prometheus + MongoDB)"
    docker-compose -f yaml/grafana-compose.yml up -d
    docker-compose -f yaml/prometheus-compose.yml up -d
    docker-compose -f yaml/mongo-compose.yml up -d
    echo "✅ Tous les services sont lancés."
    ;;
  *) echo "Option invalide" ;;
esac