#!/bin/bash
# ╔════════════════════════════════════════════════════════════════════╗
# ║ 🚀 BernardOps — Cockpit Principal (Templates2 figé)                ║
# ║ Point d’entrée unique, route les sous-menus spécialisés            ║
# ╚════════════════════════════════════════════════════════════════════╝

# === Chargement des fonctions génériques ===
source ./Functions.sh
source ./Scenarios



# === Vérification des modules locaux ===
for script in docker-cockpit.sh git-cockpit.sh system-cockpit.sh cockpit-auth.sh cockpit-diagnostics.sh; do
  if [[ -f ~/SolaizeBlazorServer/Templates2/$script ]]; then
    echo "✅ $script disponible"
  else
    echo "❌ $script manquant"
  fi
done

# === Aliases ergonomiques ===
alias nana-docker="bash ~/SolaizeBlazorServer/Templates2/docker-cockpit.sh"     # 🐳 Docker cockpit
alias nana-git="bash ~/SolaizeBlazorServer/Templates2/git-cockpit.sh"           # 🔧 Git cockpit
alias nana-system="bash ~/SolaizeBlazorServer/Templates2/system-cockpit.sh"     # 🖥️ Système cockpit
alias nana-auth="bash ~/SolaizeBlazorServer/Templates2/cockpit-auth.sh"         # 🔐 Auth cockpit
alias nana-diag="bash ~/SolaizeBlazorServer/Templates2/cockpit-diagnostics.sh"  # 🧩 Diagnostics rapides

# === Boucle principale ===
while true; do
  echo "=== 🚀 BernardOps — Cockpit Principal ==="
  echo "1) Docker 🐳"
  echo "2) Git 🔧"
  echo "3) Système 🖥️"
  echo "4) Auth 🔐"
  echo "5) Diagnostics rapides 🧩"
  echo "6) Quitter"

  read -p "Choix: " choix
  case $choix in
    1) bash ./docker-cockpit.sh ;;        # Sous-menu Docker
    2) bash ./git-cockpit.sh ;;           # Sous-menu Git
    3) bash ./system-cockpit.sh ;;        # Sous-menu Système
    4) bash ./cockpit-auth.sh ;;          # Sous-menu Auth
    5) bash ./diagnostics-rapides.sh;;   # Sous-menu Diagnostics rapides
    6) echo "👋 Au revoir BernardOps"; exit ;;
    *) echo "⚠️ Choix invalide, réessaie." ;;
  esac
done