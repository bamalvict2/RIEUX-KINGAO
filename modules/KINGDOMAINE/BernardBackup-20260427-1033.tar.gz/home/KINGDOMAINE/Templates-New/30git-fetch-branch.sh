#!/bin/bash
echo "🧠 BernardOps — Récupération et visualisation des branches distantes"

# Étape 1 : fetch
git fetch --all
echo "✅ Fetch terminé"

# Étape 2 : liste des branches distantes
echo "🌐 Branches distantes disponibles :"
git branch -r

# Étape 3 : proposer de suivre une branche
read -p "🔀 Nom d'une branche distante à suivre localement ? (laisser vide pour ignorer) " branch
if [[ "$branch" != "" ]]; then
  local_branch=$(basename "$branch")
  git checkout -b "$local_branch" "$branch"
  echo "✅ Branche locale '$local_branch' créée et liée à '$branch'"
fi