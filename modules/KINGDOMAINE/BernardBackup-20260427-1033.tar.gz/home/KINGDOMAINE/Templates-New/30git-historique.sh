#!/bin/bash

clear
echo "═══════════════════════════════════════════════════════"
echo "🧠 Menu BernardOps - Sélectionnez une opération"
echo "═══════════════════════════════════════════════════════"
echo "1. Afficher l'historique Git"
echo "2. Extraire une archive .tar.gz"
echo "3. Synchroniser NanaEparviers → Nanarieux"
echo "4. Archiver les .tar.gz anciens"
echo "5. Quitter"
echo "═══════════════════════════════════════════════════════"
read -p "🧠 Votre choix : " choix

case $choix in
    1)
        bash ~/NanaEparviers/git-history.sh
        ;;
    2)
        read -p "🧠 Chemin de l'archive : " archive
        read -p "🧠 Dossier de destination : " dest
        tar -xzf "$archive" -C "$dest"
        echo "✅ Archive extraite dans : $dest"
        ;;
    3)
        rsync -av --progress ~/NanaEparviers/ ~/Nanarieux/
        echo "✅ Synchronisation terminée"
        ;;
    4)
        bash ~/NanaEparviers/archive-old-tar.sh
        ;;
    5)
        echo "👋 À bientôt Bernard !"
        exit 0
        ;;
    *)
        echo "❌ Choix invalide"
        ;;
esac