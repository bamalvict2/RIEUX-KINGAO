#!/bin/bash

echo -e "\e[1;36m🔗 Clonage GitHub — BernardOps Universel\e[0m"
echo "────────────────────────────────────────────"

# 🔤 Demander les infos dynamiques
read -p "🔗 Nom complet du dépôt (ex: utilisateur/repo) : " REPO
read -p "🌿 Nom de la branche à cloner (défaut: main) : " BRANCH
BRANCH=${BRANCH:-main}
read -p "📂 Nom du dossier local (ex: clone-temp) : " DEST_NAME

# 📦 Clonage léger ?
read -p "📦 Clonage léger (profondeur 1) ? (o/n) : " shallow
if [[ "$shallow" == "o" ]]; then
  CLONE_OPTIONS="--depth 1"
else
  CLONE_OPTIONS=""
fi

# 🔧 Construction des chemins
DEST=~/"$DEST_NAME"
REPO_URL="https://github.com/$REPO.git"

# 🧪 Vérification du dépôt et de la branche
if ! git ls-remote --heads "$REPO_URL" "$BRANCH" &> /dev/null; then
  echo "❌ Le dépôt ou la branche est introuvable : $REPO_URL → $BRANCH"
  exit 1
fi

# 🛡️ Vérifie si le dossier existe déjà
if [ -d "$DEST" ]; then
  echo "⚠️ Le dossier $DEST existe déjà."
  read -p "❓ Le supprimer et re-cloner ? (o/n) : " confirm
  if [[ "$confirm" == "o" ]]; then
    echo "🧹 Suppression de l'ancien clone..."
    rm -rf "$DEST"
  else
    echo "❌ Clonage annulé."
    exit 1
  fi
fi

# 🔗 Clonage du dépôt GitHub
echo "📥 Clonage depuis $REPO_URL (branche: $BRANCH)..."
git clone $CLONE_OPTIONS --branch "$BRANCH" "$REPO_URL" "$DEST"

# 🧠 Marqueur d’origine
echo "Cloné depuis $REPO_URL (branche: $BRANCH) le $(date)" > "$DEST/origine.txt"

# 🧾 Ajout d’un README local
echo -e "# Cloné depuis $REPO_URL\n\nBranche : $BRANCH\nDate : $(date)" > "$DEST/README_CLONE.md"

# 👀 Afficher les 3 derniers commits
cd "$DEST"
echo ""
echo -e "\e[1;33m🕵️ Derniers commits :\e[0m"
git log --oneline -n 3

# 🎨 Ouverture dans VS Code
echo ""
echo -e "\e[1;32m🚀 Ouverture dans VS Code...\e[0m"
code "$DEST"

# 🌐 Ouvrir le dépôt GitHub dans le navigateur
echo ""
read -p "🌍 Ouvrir la page GitHub dans ton navigateur ? (o/n) : " open_web
if [[ "$open_web" == "o" ]]; then
  xdg-open "$REPO_URL"
fi

# ✅ Fin
echo ""
echo -e "\e[1;32m✅ Clonage terminé avec succès dans : $DEST\e[0m"