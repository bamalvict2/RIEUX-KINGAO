#!/bin/bash
# 🧠 BernardOps — Sauvegarde Ubuntu vers Windows (sans Docker)


#!/bin/bash
# Sauvegarde cockpit vers Windows 11 (montage réseau ou disque externe)

SRC=~/SolaizeCockpit
DEST=/mnt/w11-backup/SolaizeCockpit

echo "🚀 Sauvegarde cockpit en cours..."
rsync -av --delete $SRC $DEST
echo "✅ Sauvegarde terminée"
# en plus si panne complète




clear
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
NC='\033[0m'

echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗"
echo -e "║ 🧠  ${YELLOW}BernardOps - Sauvegarde Ubuntu vers Windows (sans Docker)${CYAN} ║"
echo -e "║ 📦  ${GREEN}Partage VMware : UBUNTUSAVEW11${CYAN}                            ║"
echo -e "║ 🕒  ${YELLOW}Date : $(date '+%Y-%m-%d %H:%M')${CYAN}                            ║"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"

echo ""
echo "🧠 Choisis ton niveau de sauvegarde BernardOps :"
echo "1 : HOME + GRUB"
echo "2 : + Ubuntu Pro"
echo "3 : + Git, API, Paquets"
echo "4 : Alias bernardsave complet"
read -p "Ton choix (1-4) : " choix

DATE=$(date '+%Y%m%d-%H%M')
BACKUP_DIR=~/BernardBackup
MOUNT_POINT="/mnt/UBUNTUSAVEW11"
ARCHIVE_NAME="BernardBackup-$DATE.tar.gz"

rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR/home"

case $choix in
  1)
    cp -r ~/SolaizeBlazorServer "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases "$BACKUP_DIR/home/"
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    ;;
  2)
    cp -r ~/SolaizeBlazorServer "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases "$BACKUP_DIR/home/"
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/"
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/"
    ;;
  3)
    cp -r ~/NanSolaizeBlazorServer "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases ~/.gitconfig "$BACKUP_DIR/home/"
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/"
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/"
    dpkg --get-selections > "$BACKUP_DIR/packages.list"
    snap list > "$BACKUP_DIR/snaps.list"
    flatpak list > "$BACKUP_DIR/flatpaks.list"
    ;;
  4)
    mkdir -p "$BACKUP_DIR/home"
    cp -r ~/SolaizeCockpit "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases ~/.gitconfig "$BACKUP_DIR/home/"
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/"
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/"
    dpkg --get-selections > "$BACKUP_DIR/packages.list"
    snap list > "$BACKUP_DIR/snaps.list"
    flatpak list > "$BACKUP_DIR/flatpaks.list"
    ;;
  *)
    echo -e "${RED}❌ Choix invalide Bernard 🧠${NC}"
    exit 1
    ;;
esac

echo "🧠 Compression en cours..."
tar -czvf "$HOME/$ARCHIVE_NAME" -C "$BACKUP_DIR" .

echo "🧠 Montage du dossier partagé Windows..."
sudo mkdir -p "$MOUNT_POINT"
sudo mount -t fuse.vmhgfs-fuse ".host:/UBUNTUSAVEW11" "$MOUNT_POINT" -o allow_other,uid=$(id -u),gid=$(id -g)

DEST_FOLDER="$MOUNT_POINT/utilisation"
sudo mkdir -p "$DEST_FOLDER"
sudo cp "$HOME/$ARCHIVE_NAME" "$DEST_FOLDER/"

echo -e "${GREEN}✅ Sauvegarde BernardOps terminée et copiée vers : $DEST_FOLDER/$ARCHIVE_NAME${NC}"
echo "$(date '+%Y-%m-%d %H:%M') | $USER | Sauvegarde niveau $choix | Archive: $ARCHIVE_NAME" >> ~/bernardops.log