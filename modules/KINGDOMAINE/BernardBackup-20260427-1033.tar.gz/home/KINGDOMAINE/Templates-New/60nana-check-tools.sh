#!/bin/bash
# nana-check-tools.sh — Préambule NANABOOT

echo "======================================"
echo "🔍 Vérification des outils critiques"
echo "🚀 Préambule NANABOOT"
echo "======================================"

# Node.js
if command -v node >/dev/null 2>&1; then
  echo "✅ Node.js présent : $(node -v)"
else
  echo "⚠️ Node.js absent"
fi

# npm
if command -v npm >/dev/null 2>&1; then
  echo "✅ npm présent : $(npm -v)"
else
  echo "⚠️ npm absent"
fi

# Docker
if command -v docker >/dev/null 2>&1; then
  echo "✅ Docker présent : $(docker -v)"
else
  echo "⚠️ Docker absent"
fi

# Buildx
if docker buildx version >/dev/null 2>&1; then
  echo "✅ Buildx présent : $(docker buildx version)"
else
  echo "⚠️ Buildx absent → installation en cours..."
  mkdir -p ~/.docker/cli-plugins
  curl -L https://github.com/docker/buildx/releases/latest/download/docker-buildx-linux-amd64 \
    -o ~/.docker/cli-plugins/docker-buildx
  chmod +x ~/.docker/cli-plugins/docker-buildx
  docker buildx version && echo "✅ Buildx installé"
fi

# kubectl
if command -v kubectl >/dev/null 2>&1; then
  echo "✅ kubectl présent : $(kubectl version --client --short)"
else
  echo "⚠️ kubectl absent"
fi

echo "======================================"
echo "✅ Vérification des outils terminée"
echo "======================================"