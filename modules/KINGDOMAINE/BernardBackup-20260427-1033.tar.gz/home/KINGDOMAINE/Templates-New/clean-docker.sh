#!/bin/bash

echo "🧼 Nettoyage cockpit Docker - $(date)"
echo ""

# === FONCTION DE VALIDATION ===
function checkpoint_clean() {
  echo ""
  echo "🛑 Étape : $1"
  echo "1. Valider et exécuter"
  echo "2. Passer cette étape"
  echo "3. Quitter le nettoyage"
  read -p "👉 Choix [1/2/3] : " CHOICE
  case "$CHOICE" in
    1) echo "✅ Étape validée : $1" ;;
    2) echo "⏩ Étape sautée : $1"; return 1 ;;
    3) echo "❌ Nettoyage interrompu à : $1"; exit 1 ;;
    *) echo "⛔ Choix invalide. Abandon."; exit 1 ;;
  esac
  return 0
}

# === 1. Conteneurs arrêtés ===
echo "📦 Conteneurs arrêtés :"
docker ps -a --filter "status=exited"
checkpoint_clean "Suppression des conteneurs arrêtés" && docker container prune -f

# === 2. Images non utilisées ===
echo ""
echo "🖼️ Images non utilisées :"
docker images -f "dangling=true"
checkpoint_clean "Suppression des images dangling" && docker image prune -f

# === 3. Volumes non utilisés ===
echo ""
echo "🗃️ Volumes non utilisés :"
docker volume ls -f "dangling=true"
checkpoint_clean "Suppression des volumes inutilisés" && docker volume prune -f

# === 4. Réseaux non utilisés ===
echo ""
echo "🌐 Réseaux non utilisés :"
docker network ls | grep "bridge"
checkpoint_clean "Suppression des réseaux inutilisés" && docker network prune -f

# === 5. Espace disque final ===
echo ""
echo "📊 Espace disque après nettoyage :"
df -h | grep '/$'

echo ""
echo "✅ Nettoyage Docker cockpit terminé à $(date)"