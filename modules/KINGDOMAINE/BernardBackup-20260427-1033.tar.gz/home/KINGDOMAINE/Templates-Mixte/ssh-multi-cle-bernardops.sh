#!/bin/bash

# ============================
#   COULEURS BERNARDOPS
# ============================
VERT="\e[32m"
ROUGE="\e[31m"
BLEU="\e[34m"
JAUNE="\e[33m"
RESET="\e[0m"

# ============================
#   FONCTIONS
# ============================

generer_cle() {
    echo -e "${BLEU}--- Génération d'une nouvelle clé SSH ---${RESET}"
    read -p "Nom de la clé (ex: perso, travail, serveur) : " nom
    read -p "Email GitHub ou serveur : " email

    ssh-keygen -t ed25519 -C "$email" -f ~/.ssh/id_ed25519_$nom

    echo -e "${VERT}Clé générée : ~/.ssh/id_ed25519_${nom}${RESET}"
}

ajouter_agent() {
    echo -e "${BLEU}--- Ajout d'une clé à l'agent SSH ---${RESET}"
    read -p "Nom de la clé (ex: perso, travail, serveur) : " nom

    ssh-add ~/.ssh/id_ed25519_$nom
    echo -e "${VERT}Clé ajoutée à l'agent.${RESET}"
}

afficher_pub() {
    echo -e "${BLEU}--- Affichage de la clé publique ---${RESET}"
    read -p "Nom de la clé (ex: perso, travail, serveur) : " nom

    echo -e "${JAUNE}"
    cat ~/.ssh/id_ed25519_${nom}.pub
    echo -e "${RESET}"

    echo -e "${VERT}Ajoute cette clé dans GitHub ou ton serveur.${RESET}"
}

configurer_ssh() {
    echo -e "${BLEU}--- Configuration automatique du fichier ~/.ssh/config ---${RESET}"

    read -p "Nom de la clé (ex: perso, travail, serveur) : " nom
    read -p "Alias Host (ex: github-perso, github-travail, kingdom) : " alias
    read -p "HostName (ex: ssh.github.com, 192.168.1.50) : " host
    read -p "Port (443 pour GitHub, 22 sinon) : " port

    cat >> ~/.ssh/config <<EOF

Host $alias
    HostName $host
    User git
    Port $port
    IdentityFile ~/.ssh/id_ed25519_$nom
    IdentitiesOnly yes
EOF

    echo -e "${VERT}Bloc ajouté dans ~/.ssh/config${RESET}"
}

tester_connexion() {
    echo -e "${BLEU}--- Test de connexion SSH ---${RESET}"
    read -p "Alias Host à tester (ex: github-perso) : " alias

    ssh -T $alias
}

liste_cles() {
    echo -e "${BLEU}--- Liste des clés SSH disponibles ---${RESET}"
    ls -1 ~/.ssh/id_ed25519_* 2>/dev/null | sed 's/.pub//g'
}

menu_principal() {
    clear
    echo -e "${JAUNE}==============================================${RESET}"
    echo -e "${JAUNE}   COCKPIT MULTI-CLÉ SSH – BERNARDOPS EDITION ${RESET}"
    echo -e "${JAUNE}==============================================${RESET}"

    echo -e "${BLEU}1) Générer une nouvelle clé SSH${RESET}"
    echo -e "${BLEU}2) Ajouter une clé à l'agent SSH${RESET}"
    echo -e "${BLEU}3) Afficher une clé publique${RESET}"
    echo -e "${BLEU}4) Ajouter un bloc dans ~/.ssh/config${RESET}"
    echo -e "${BLEU}5) Tester une connexion SSH${RESET}"
    echo -e "${BLEU}6) Lister les clés disponibles${RESET}"
    echo -e "${BLEU}7) Quitter${RESET}"

    echo ""
    read -p "Choix : " choix

    case $choix in
        1) generer_cle ;;
        2) ajouter_agent ;;
        3) afficher_pub ;;
        4) configurer_ssh ;;
        5) tester_connexion ;;
        6) liste_cles ;;
        7) exit 0 ;;
        *) echo -e "${ROUGE}Choix invalide.${RESET}" ;;
    esac

    echo ""
    read -p "Appuie sur ENTER pour revenir au menu..."
    menu_principal
}

# Lancement du menu
menu_principal