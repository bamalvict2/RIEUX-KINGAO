#!/bin/bash
echo "=== 🌐 Git Remote Cockpit ==="
echo "1) Lister les remotes"
echo "2) Ajouter un remote 'origin'"
echo "3) Supprimer un remote"
echo "4) Modifier l’URL d’un remote"
echo "5) Vérifier la connexion SSH"
echo "6) Retour menu Git"

read -p "Choix: " choix_remote
case $choix_remote in
  1) git remote -v ;;
  2) read -p "URL du dépôt distant (SSH recommandé): " url
     git remote add origin "$url"
     echo "✅ Remote 'origin' ajouté : $url" ;;
  3) read -p "Nom du remote à supprimer: " remote_name
     git remote remove "$remote_name"
     echo "✅ Remote '$remote_name' supprimé" ;;
  4) read -p "Nom du remote à modifier: " remote_name
     read -p "Nouvelle URL: " new_url
     git remote set-url "$remote_name" "$new_url"
     echo "✅ Remote '$remote_name' mis à jour → $new_url" ;;
  5) echo "🔑 Test de connexion SSH vers GitHub..."
     ssh -T git@github.com ;;
  6) bash ./git-cockpit.sh ;;
  *) echo "⚠️ Choix invalide" ;;
esac