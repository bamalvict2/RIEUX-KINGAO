#!/bin/bash
# 🧠 BernardOps — Sauvegarde EPARVIER vers Windows (VMware + FUSE)

# --- CONFIGURATION PRINCIPALE ---
SRC=~/KINGDOMAINE
DEST=/mnt/UBUNTUSAVEW11/KINGDOMAINE
MOUNT_POINT="/mnt/UBUNTUSAVEW11"

# --- COULEURS ---
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
NC='\033[0m'

clear
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗"
echo -e "║ 🧠  ${YELLOW}BernardOps - Sauvegarde EPARVIER vers Windows (VMware) ${CYAN}║"
echo -e "║ 📦  ${GREEN}Partage VMware : UBUNTUSAVEW11                         ${CYAN}║"
echo -e "║ 🕒  ${YELLOW}Date : $(date '+%Y-%m-%d %H:%M')                       ${CYAN}║"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"

echo ""
echo "🧠 Choisis ton niveau de sauvegarde BernardOps :"
echo "1 : HOME + GRUB"
echo "2 : + Ubuntu Pro"
echo "3 : + Git, API, Paquets"
echo "4 : Sauvegarde complète"
read -p "Ton choix (1-4) : " choix

DATE=$(date '+%Y%m%d-%H%M')
BACKUP_DIR=~/BernardBackup
ARCHIVE_NAME="BernardBackup-$DATE.tar.gz"

# --- RESET DU DOSSIER TEMP ---
rm -rf "$BACKUP_DIR"
mkdir -p "$BACKUP_DIR/home"
mkdir -p "$BACKUP_DIR/grub"
mkdir -p "$BACKUP_DIR/ubuntu-pro-config"
mkdir -p "$BACKUP_DIR/ubuntu-pro-data"

# --- MENU ---
case "$choix" in
  1)
    cp -r "$SRC" "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases "$BACKUP_DIR/home/" 2>/dev/null || true
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    ;;
  2)
    cp -r "$SRC" "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases "$BACKUP_DIR/home/" 2>/dev/null || true
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/" 2>/dev/null || true
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/" 2>/dev/null || true
    ;;
  3)
    cp -r "$SRC" "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases ~/.gitconfig "$BACKUP_DIR/home/" 2>/dev/null || true
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/" 2>/dev/null || true
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/" 2>/dev/null || true
    dpkg --get-selections > "$BACKUP_DIR/packages.list"
    snap list > "$BACKUP_DIR/snaps.list" 2>/dev/null || true
    flatpak list > "$BACKUP_DIR/flatpaks.list" 2>/dev/null || true
    ;;
  4)
    cp -r "$SRC" "$BACKUP_DIR/home/"
    cp ~/.bashrc ~/.bash_history ~/.bash_aliases ~/.gitconfig "$BACKUP_DIR/home/" 2>/dev/null || true
    sudo cp -r /boot/grub "$BACKUP_DIR/grub/"
    sudo cp -r /etc/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-config/" 2>/dev/null || true
    sudo cp -r /var/lib/ubuntu-advantage "$BACKUP_DIR/ubuntu-pro-data/" 2>/dev/null || true
    dpkg --get-selections > "$BACKUP_DIR/packages.list"
    snap list > "$BACKUP_DIR/snaps.list" 2>/dev/null || true
    flatpak list > "$BACKUP_DIR/flatpaks.list" 2>/dev/null || true
    ;;
  *)
    echo -e "${RED}❌ Choix invalide Bernard 🧠${NC}"
    exit 1
    ;;
esac

# --- COMPRESSION ---
echo "🧠 Compression en cours..."
tar -czvf "$HOME/$ARCHIVE_NAME" -C "$BACKUP_DIR" .

# --- MONTAGE VMWARE ---
echo "🧠 Montage du dossier partagé Windows (VMware FUSE)..."
sudo mkdir -p "$MOUNT_POINT"
sudo mount -t fuse.vmhgfs-fuse ".host:/UBUNTUSAVEW11" "$MOUNT_POINT" -o allow_other,uid=$(id -u),gid=$(id -g)

# --- COPIE VERS WINDOWS ---
DEST_FOLDER="$DEST"
sudo mkdir -p "$DEST_FOLDER"
sudo cp "$HOME/$ARCHIVE_NAME" "$DEST_FOLDER/"

echo -e "${GREEN}✅ Sauvegarde BernardOps terminée et copiée vers : $DEST_FOLDER/$ARCHIVE_NAME${NC}"
echo "$(date '+%Y-%m-%d %H:%M') | $USER | Sauvegarde niveau $choix | Archive: $ARCHIVE_NAME" >> ~/bernardops.log